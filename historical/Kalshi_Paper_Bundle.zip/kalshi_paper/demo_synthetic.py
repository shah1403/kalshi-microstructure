"""Deterministic invented feed for visual inspection, NOT market performance."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from paper_engine import Settings, Engine, dashboard

root=Path(__file__).resolve().parent
e=Engine(Settings(ticker='SYNTHETIC DEMO - NOT MARKET RESULTS',session_loss_limit=100,
                  plot_points=4000))
for i in range(1600):
    phase=i%240
    # Alternating trends, flat windows, and a later sign reversal of the invented relation.
    mid=.35+.005*phase if phase<60 else .65 if phase<120 else .65-.005*(phase-120) if phase<180 else .35
    sign=1 if phase<120 else -1
    if i>=1000: sign=-sign
    bq,aq=(1000,40) if sign==1 else (40,1000)
    t=i*.1
    for dt in (0.,.02,.04):
        e.book.snapshot({'yes_dollars_fp':[[f'{mid-.01:.4f}',str(bq)]],
                         'no_dollars_fp':[[f'{1-mid-.01:.4f}',str(aq)]]},t+dt)
        e.tick(t+dt,is_book=True)
        if dt==0.:e.tick(t+.001,is_trade=True)
e.request_stop(160)
e.book.last_t=160.02
e.tick(160.02,is_book=True)
fig=dashboard(e)
fig.savefig(root/'synthetic_dashboard.png',dpi=120)
plt.close(fig)
(root/'synthetic_stats.json').write_text(json.dumps({'SYNTHETIC_NOT_MARKET_RESULTS':True,**e.stats()},indent=2))
print(json.dumps({'SYNTHETIC_NOT_MARKET_RESULTS':True,**e.stats()},indent=2))
