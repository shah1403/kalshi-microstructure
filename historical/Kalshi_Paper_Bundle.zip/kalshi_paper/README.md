# Kalshi live paper notebook

Open `Kalshi_Live_Paper.ipynb` in Jupyter and run cells in order. It contains the entire engine;
no companion Python file is needed. Alternatively copy the CODE CELL sections from
`copy_paste_cells.txt` into separate notebook cells. The dependency-install cell needs internet.

1. Revoke the private key exposed in chat and create a replacement. Save that key on your
   computer as a PEM file. Enter its local path and key ID at the notebook prompts;
   do not paste credentials into code or notebook outputs.
2. Browse the market list, then enter an active binary market ticker, not a series/event ticker.
   An active market with frequent trades and available depth is necessary for useful observations.
3. Set fictional bankroll and budget. Defaults: $100 paper cash, $5 base budget per trade,
   probability-scaled size, integer contracts, one position at a time. A $5 total bankroll is
   allowed but often produces a size below one contract and therefore no trade.
4. Start, watch the dashboard, and use the Stop cell when finished. The dashboard cell runs
   for five minutes; the background feed continues until Stop or kernel shutdown.
5. Stop exports the ledger and feed recording. The final cell replays the recording with
   exactly the same engine. It checks history counts and realized PnL agreement.

The program has market-data GET requests and WebSocket subscriptions only. It does not send
orders or read your account balance. Monetary amounts refer to the local paper ledger.

## Locked signal

At a qualifying anchor, estimate first-passage direction from the entire matured history in
the same `(imbalance bucket, most recent observable state)` cell. With counts DOWN/ZERO/UP,
the smoothed probabilities are `(count + 0.5)/(cell total + 1.5)`. This is a Dirichlet posterior
mean for categorical outcomes, not regression. Empty cells remain uniform; there is no
unconditional fallback. History begins empty on each session and expands; it is not a fixed
length window. Default global initialization is 30 matured anchors and local minimum is 1.
The local sample size is displayed: small cells can give unstable probabilities.

Anchors need absolute imbalance at least 0.8 for 3 consecutive trade observations, a spread
in its causal bottom quartile, and 5 trade messages since the previous anchor. The 3-observation
persistence requirement is an explicit new live setting; set 1 to disable it. Imbalance sign
does not dictate the trade direction. Its bucket conditions the observed distribution.
Changes after locking are recorded, rather than retrospectively deleting the observation.

Reference outcomes compare buying one YES versus buying one NO. The first side whose executable
sale proceeds exceed its purchase cost plus both fees and modeled slippage is the first-passage
direction. Neither crossing within the next 50 actual public trade messages gives ZERO.
Block prints are excluded; contract volume and book updates do not increment this trade clock.
Outcomes enter frequency counts only after their full 50-trade exposure, to avoid fast-outcome
selection bias. Already observed hits may update the current state sooner. Missing-data windows
are censored, not counted as ZERO. Overlapping anchors are dependent observations.

The largest probability wins; unique ZERO means abstain. Exception: while ZERO is strictly
largest, trade if UP or DOWN is strictly greater than 45%, at `floor(0.45 * normal size)`.
Ties abstain. Normal size uses `p_direction * min(base budget, cash fraction * available cash)`
and buys as many whole contracts as depth, fees and that budget permit. This is a sizing
heuristic, not an optimal Kelly rule or evidence of positive expected PnL.

## Execution and measurements

- Marketable full-size paper fills walk reconstructed L2 depth, using 50% of displayed volume
  and $0.001 additional adverse slippage per contract per leg by default. If the complete size
  cannot fill, it is rejected; exits remain pending for another attempt. This is an explicit
  simulated fill-or-kill policy, not a model of partial-fill market orders or limit-order queues.
- Add 5 ms after LOCAL receipt on both entry and exit, and fill on the first valid subsequent
  book update after that delay. This can exceed 5 ms and differs from an exact arrival-time book.
  Source-to-receipt lag and actual simulated execution delays are recorded.
- Exit on the first observed actual-size net-positive liquidation opportunity, 50-trade timeout,
  or an operational stop. Exit fills can be negative after a positive signal. Operational defaults
  also include a 300-second holding limit, closing buffer and $10 session loss limit. They are
  separately labeled and cannot guarantee a maximum loss during gaps or unavailable depth.
- Fees use resolved series/event multiplier and taker quadratic schedule. Supported fee types
  are checked; fee changes pause the strategy. Default rounding is conservatively per contract
  to $0.0001. The July 2026 official schedule prose uses this quantum while its table still shows
  cent-rounded examples; `fee_quantum='.01'` permits a cent-rounding stress scenario. Fee rounding
  and fill splitting remain estimates, not verified private execution records.
- DA is direction accuracy among ready, matured forecasts where a direction was chosen AND a
  reference move occurred. Its denominator excludes ZERO. The dashboard separately reports
  correct-direction hit rate including ZERO, trade-only DA, timeout count, net win rate,
  pending/censored outcomes, gross and net closed PnL, liquidation equity and observed drawdown.
- A correct reference direction need not imply profitable execution of your larger delayed
  position. Gaps retain open inventory. Unknown liquidation values are explicit, so observed
  maximum drawdown is a lower bound when prices cannot be observed. Final settlement is ignored;
  inventory that cannot be exited stays unresolved.
- Raw messages, timestamps, forecasts, sample sizes, trades, fees, imbalance changes and events
  are exported. Post-50 same-side crossings up to 500 trades are diagnostics only.

This is a research paper simulator, not exchange-equivalent high-fidelity execution. It cannot
observe hidden liquidity, your hypothetical market impact, exact executable depth at server
arrival, or atomic ordering between separate trade and book channels. Sequence checks, staleness
checks and reconnect snapshots reduce data errors but do not eliminate those limitations.
The kernel must stay running; restart recovery of open paper positions is not implemented.
Full ledgers remain in memory, so very long sessions require monitoring memory and disk usage.

## Validation and files

`python -m unittest discover -s . -p 'test_paper.py' -v` runs offline deterministic tests.
`demo_synthetic.py` creates the dashboard preview from invented prices. It is NOT a backtest
on market data and its PnL is not evidence of an edge. `build_notebook.py` embeds the current
engine into the notebook and text file. The supplied exposed credential was never used.
Authenticated live connectivity has not been verified in the build environment.

Official references, checked 2026-09-27:
- https://docs.kalshi.com/getting_started/quick_start_websockets
- https://docs.kalshi.com/websockets/orderbook-updates
- https://docs.kalshi.com/websockets/public-trades
- https://docs.kalshi.com/websockets/market-and-event-lifecycle
- https://docs.kalshi.com/api-reference/market/get-series
- https://kalshi.com/docs/kalshi-fee-schedule.pdf
