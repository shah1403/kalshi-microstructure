"""Offline notebook validation; does not execute discovery or credential cells."""
import ast
import json
from pathlib import Path
import types
import sys

root=Path(__file__).resolve().parent
nb=json.loads((root/'Kalshi_Live_Paper.ipynb').read_text())
try:
    import nbformat
except ImportError:
    print('nbformat not installed; validating structure, syntax and offline cells directly.')
else:
    nbformat.validate(nb)
assert nb['nbformat']==4
module=types.ModuleType('notebook_offline_validation')
sys.modules[module.__name__]=module
codes=[c for c in nb['cells'] if c['cell_type']=='code']
for index,cell in enumerate(codes):
    text=''.join(cell['source'])
    assert not cell['outputs'] and cell['execution_count'] is None
    if text.startswith('%pip'):continue
    compile(text,f'notebook_code_{index}','exec',flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    if index in (1,2):exec(text,module.__dict__)
assert ''.join(codes[1]['source'])==(root/'paper_engine.py').read_text()
for path in root.iterdir():
    if path.suffix in ('.py','.txt','.md','.ipynb','.json'):
        assert ('-----BEGIN RSA '+'PRIVATE KEY-----') not in path.read_text(),path
print(f'Validated {len(codes)} code cells; embedded engine and quick checks executed offline.')
