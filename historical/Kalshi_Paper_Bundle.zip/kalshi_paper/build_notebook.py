"""Build the self-contained notebook and equivalent copy/paste cells, with no credentials."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
cells=[]
def md(text): cells.append(dict(cell_type='markdown',metadata={},source=text.splitlines(True)))
def code(text): cells.append(dict(cell_type='code',metadata={},execution_count=None,outputs=[],source=text.splitlines(True)))

md('''# Kalshi live paper research notebook

**Paper only. No order-submission endpoint exists in this notebook.**
Production market data, local fictional cash and inventory. No YES/NO settlement payout is ever credited.
Revoke the private key previously pasted into chat and use a replacement. Credentials are loaded from
your local PEM file and a hidden key-ID prompt; they are never written into the notebook or feed log.

Run cells in order. Python 3.10+ and Jupyter are required. The notebook embeds its engine, so no companion
module is needed. Select one live binary market. A sports-series discovery cell is supplied.
Let the session collect observations: a cold start has **no probability history** and cannot immediately trade.

### Precisely what is being tested
* Expanding empirical counts for first-passage states, conditioned on signed top-level imbalance bucket
  and the latest observable resolved state. `mode="imbalance"` selects the comparison variant.
* Fixed bins at −0.8, −0.4, 0.4, 0.8. No assumption that positive imbalance predicts UP.
* Strong imbalance means |I| ≥ 0.8. This notebook explicitly requires 3 consecutive **trade observations**
  with the same strong sign. Set `persistence_trades=1` to remove the new persistence requirement.
* An anchor every 5 actual trade messages while locked, with spread in its expanding bottom quartile.
  It is **not** every fifth qualifying row; the spacing is measured on the trade-message clock.
* Reference label size is always **one contract**. +1 means a YES purchase can first be liquidated above
  its entry cost plus both taker fees; −1 means the same for a NO purchase. These are race labels.
  0 means neither opportunity was observed by 50 subsequent non-block trade messages.
  The data clock counts distinct trade IDs, not contracts of volume or quote updates.
* Snapshot/print streams are processed in local receipt order. Their cross-channel exchange ordering
  is not guaranteed. This limitation is logged and is not fixed by calling the clock exact.
* Early outcomes may update observable state at the next later receipt time, but **counts wait until
  the full 50-trade exposure has elapsed**. Gaps censor unfinished windows, never convert them to 0.
* Posterior mean: `(counts + 0.5)/(sum(counts) + 1.5)`. Total warmup 30; default minimum cell count 1
  preserves the old sparse-cell behavior. Set `min_cell=30` for a distinct stricter experiment.
  Sample counts are displayed. Overlapping anchors are correlated; 30 is not 30 independent events.

### Position size and 45% rule
Let p be the probability of the selected direction. The entry cash budget is
`p * min(order_budget, cash_fraction * available_cash)`.
Normal size is the largest whole-contract fill within that budget, displayed-depth allowance and
`max_contracts`. This is a **probability-scaled budget heuristic, not Kelly or an expected-PnL optimum**.
If the direction is the unique largest state, use normal size. If 0 is strictly largest and a direction
is strictly above 45%, use `floor(0.45 * normal_size)`. All ties abstain. A result below one contract abstains.
For example (down, zero, up) = (0.04, 0.50, 0.46) qualifies; (0.05, 0.50, 0.45) does not.
An imbalance change after the anchor is flagged; it does not secretly reverse the trade.

### Execution and fees
* Marketable fill-or-kill **paper** orders walk both sides of the reconstructed L2 book. No passive fills
  or queue priority are assumed. Default allowance is 50% of visible size, plus $0.001 adverse slippage
  per contract per leg. These are stress assumptions, not calibrated exchange impact estimates.
* Both entry and exit use an added 5 ms delay **after local receipt**. They execute only on the first
  subsequent valid book event at/after the delay. A timer never fills against a cached quote.
  Internet/data delay and Python/dashboard scheduling are additional. 5 ms end-to-end is not claimed.
* Actual-size exit: first observed net-profitable liquidation opportunity, otherwise trade 50.
  The delayed exit executes even if that opportunity has become a loss. Insufficient exit depth leaves
  inventory open and retries on a later book. One position/pending entry at a time, fully cash-funded.
* Extra operational exits are clearly labeled: 300 seconds without finishing the trade window, loss limit,
  close buffer, manual stop, or recovery after a feed gap. These are additions to the historical strategy.
* Fees use public series fee type/multiplier and event overrides. Unsupported fee types halt startup.
  Supported types: quadratic and quadratic-with-maker-fees, using taker fees on both legs.
  The July 7, 2026 schedule says 0.07 × multiplier × q × p × (1−p), with centicent rounding.
  Default quantum is $0.0001; per-contract rounding conservatively splits fills. Use $0.01 for comparison
  with our older cent-rounded backtests. The PDF's cent-rounded example table and prose differ; actual
  counterparty fill grouping and account-specific fee rules cannot be reconstructed from public depth.
* A gap freezes signals, censors unfinished labels and preserves inventory; the next fresh tradable book
  attempts delayed liquidation. Terminal/settled markets cannot generate simulated fills. Any remaining
  inventory is **unresolved**, not a loss quietly removed from the ledger or a settlement win.

### Statistics
DA is correct first-passage direction / scorable nonzero labels, conditional on a directional signal.
The dashboard also reports correct-direction hit rate including zero outcomes, the DA denominator,
traded DA, censored and pending trades, win rate, gross/net closed PnL, paid fees including open positions,
cash, liquidation equity, drawdown, and post-50 same-side opportunities. DA excludes missing labels;
cash/net/PnL retain the associated trades. Drawdown is a lower bound wherever liquidation marks are missing.
Post-50 observations never enter the 50-trade probability counts or booked profit. They are diagnostic
same-side opportunities and need not precede an intervening opposite move.

This is a research simulator, not proof of a profitable or unattended-safe strategy. It has no model of
hidden liquidity, counterfactual market impact, matching-engine latency or queue priority. A notebook
kernel must remain running. Raw logs support deterministic receipt-order replay; restarting creates a
new session rather than silently dropping or restoring real-world positions.
''')
code('''%pip -q install "numpy>=1.24,<3" "pandas>=2,<4" "matplotlib>=3.7,<4" "websockets>=14,<16" "cryptography>=42"
''')
md('## Embedded engine\nRun this cell once. It contains no credentials or real-order functionality.')
code((ROOT/'paper_engine.py').read_text())
md('## Quick local checks\nThese are synthetic mechanics checks, not performance results. The downloadable bundle contains the full offline unit-test suite.')
code('''assert action([.04,.50,.46]) == (1,.45,'reduced_45')
assert action([.05,.50,.45])[0] == 0
assert action([.05,.475,.475])[0] == 0
assert action([.05,.15,.80]) == (1,1.,'normal')
test_cfg = Settings()
assert abs(fee([(1,.5)],1,test_cfg)-.0175)<1e-10
test_book = Book()
test_book.snapshot({'yes_dollars_fp':[['0.4900','100']], 'no_dollars_fp':[['0.4800','100']]},0)
assert abs(test_book.quote()['ask']-.52)<1e-10
assert abs(value(test_book.fill(-1,True,1,test_cfg))-.511)<1e-10
print('Basic probability, fee, and complementary-book checks passed.')
''')
md('## Find a market\nChoose a live market with current trades and visible depth. This lists at most 600 open markets in the selected series, ranked by reported 24-hour volume. Volume does not guarantee current activity. Change the series to NFL/NBA/college sports if desired.')
code('''# Public GETs only; no credential needed for discovery.
SERIES = "KXMLBGAME"  # alternatives: KXNFLGAME, KXNBAGAME, KXNCAAFGAME
candidates = list_markets(SERIES, pages=3)
display(candidates.head(30))
''')
md('## Configure one paper session\nThe default $100 is fictional cash, not your Kalshi balance. You can set bankroll=5. With tiny balances, whole-contract rounding often makes the reduced-size rule abstain. No real balance is read.')
code('''from dataclasses import replace
cfg = Settings(
    ticker=input("Paste an exact market ticker from the table: ").strip(),
    bankroll=100.0, order_budget=5.0, cash_fraction=0.25, max_contracts=20,
    mode="imbalance_state", warmup=30, min_cell=1,
    persistence_trades=3, latency_ms=5.0,
    depth_fraction=0.50, adverse_slippage=0.001,
    fee_quantum="0.0001", fee_scope="contract",
    max_hold_s=300, session_loss_limit=10,
)
assert cfg.ticker and cfg.ticker != "REPLACE_WITH_MARKET_TICKER"
market_info, series_info = market_metadata(cfg.ticker)
display({"title": market_info.get("title"), "status": market_info["status"],
         "close_time": market_info["close_time"], "fee_type": series_info["fee_type"],
         "fee_multiplier": series_info["fee_multiplier"], "paper_cash": cfg.bankroll})
''')
md('## Load replacement credentials privately\nSave your new PEM key outside this notebook. Do not paste its contents in a cell. Credentials remain in kernel memory, never in exported logs. The key ID is entered through a hidden prompt. Keep an accurate system clock for RSA signatures.')
code('''import getpass, os
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey
key_id = os.environ.get("KALSHI_API_KEY_ID") or getpass.getpass("Replacement Kalshi API key ID: ")
key_path = Path(os.environ.get("KALSHI_PRIVATE_KEY_PATH") or input("Path to replacement .pem key file: ")).expanduser()
pem = key_path.read_bytes()
try:
    private_key = serialization.load_pem_private_key(pem, password=None)
except TypeError:
    private_key = serialization.load_pem_private_key(pem, password=getpass.getpass("PEM passphrase: ").encode())
del pem
assert isinstance(private_key, RSAPrivateKey), "This notebook's signer requires an RSA key."
print("RSA key loaded privately. Only market-data subscriptions will be authenticated.")
''')
md('## Start recording and paper trading\nThis starts an asyncio task in the Jupyter kernel. Keep the kernel alive. Use the Stop cell before restarting; never overwrite an existing recording.')
code('''from datetime import datetime, timezone
if "session" in globals() and session.task and not session.task.done():
    raise RuntimeError("An existing session is running; use the Stop cell first.")
run_dir = Path("paper_runs") / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
session = PaperSession(cfg, key_id, private_key, output=run_dir)
session.start()
await asyncio.sleep(2)
print("Recording to", run_dir)
print("Status:", session.engine.stats())
if session.error: print("Connection/status message:", session.error)
''')
md('## Live dashboard\nSquares mark persistent imbalance; triangles mark entry with expected YES-price direction; green circles/red Xs mark correct/wrong reference first passages; orange marks identify timeouts. Black Xs are movement exits; violet Xs are operational exits. Trade-table PnL can be negative after a correct movement because the actual fill is delayed and sized differently.\n\nThis refreshes for 5 minutes and returns; the background session keeps running. Rerun this cell to watch longer, or use Stop. Rendering is done in a worker thread from a copy of state so it does not intentionally block data processing.')
code('''import copy, io
import pandas as pd
from IPython.display import display, Image
import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt

def render_png(engine_copy):
    fig = dashboard(engine_copy)
    stream = io.BytesIO()
    fig.savefig(stream, format="png", dpi=105)
    plt.close(fig)
    return stream.getvalue()

stats_display = display(pd.DataFrame(), display_id=True)
plot_display = display(Image(data=await asyncio.to_thread(render_png, copy.deepcopy(session.engine))), display_id=True)
for _ in range(30):
    stats = session.engine.stats()
    if session.receipt_lags:
        stats["median_source_to_receipt_ms"] = float(np.median(session.receipt_lags))
    stats["session_error"] = session.error
    stats_display.update(pd.Series(stats, name="Live paper statistics").to_frame())
    plot_display.update(Image(data=await asyncio.to_thread(render_png, copy.deepcopy(session.engine))))
    if session.task.done():
        print("Session ended; inspect error/status and unresolved inventory.")
        break
    await asyncio.sleep(10)
''')
md('## Stop and retain every position\nStop requests a delayed exit from a fresh book, waits up to 35 seconds and exports the ledger. If no valid liquidation can be observed, inventory is saved as unresolved. No invented close or settlement cash is credited.')
code('''import pandas as pd
from IPython.display import display
stats = await session.stop()
display(pd.Series(stats, name="Final paper statistics").to_frame())
display(pd.DataFrame(session.engine.trades).reindex(columns=[
    "id","side","q","tier","entry_t","exit_t","exit_reason","gross","fees","net",
    "wait_trades","exit_delay_ms","gap_exposed"]))
print("Raw feed, forecasts, trades, events and ledger:", session.output.resolve())
if session.engine.position:
    print("UNRESOLVED INVENTORY:", session.engine.position)
''')
md('## Replay your own recorded feed\nReplay uses the same receipt-order engine and parameters. It does not search for the best horizon or threshold. Only replay a completed recording. Compare counts, forecasts and realized ledger; live display timing does not alter replay event ordering.')
code('''replayed = replay_recording(session.output / "feed.jsonl.gz")
live_stats = session.engine.stats()
replayed_stats = replayed.stats()
for name in ("trade_messages", "history_n", "closed_trades", "gross_closed", "net_closed"):
    assert np.isclose(live_stats[name], replayed_stats[name]), (name, live_stats[name], replayed_stats[name])
display(pd.Series(replayed_stats, name="Replayed statistics").to_frame())
replayed.export(session.output / "replay")
print("Receipt-order replay matched the main count and realized-PnL fields.")
''')
md('''## Sources and validation

Official documentation checked September 27, 2026:
* https://docs.kalshi.com/getting_started/quick_start_websockets
* https://docs.kalshi.com/websockets/orderbook-updates
* https://docs.kalshi.com/websockets/public-trades
* https://docs.kalshi.com/websockets/market-and-event-lifecycle
* https://docs.kalshi.com/api-reference/market/get-series
* https://kalshi.com/docs/kalshi-fee-schedule.pdf

The bundled tests exercise authentication signing with a newly generated test key, depth/VWAP,
complementary YES/NO prices, fee rounding, both latency legs, negative delayed exits, sparse-cell
probabilities, the strict 45% condition, position funding, sequence gaps, trade-ID deduplication,
settlement exclusion, and deterministic raw-feed replay. Authenticated live operation has not been
verified in this environment; the exposed user key was not used. The dashboard preview is synthetic.
''')
notebook=dict(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
                                  'language_info':{'name':'python','version':'3.10'}},nbformat=4,nbformat_minor=5)
for i,c in enumerate(cells):c['id']=f'cell-{i:03}'
(ROOT/'Kalshi_Live_Paper.ipynb').write_text(json.dumps(notebook,indent=1),encoding='utf-8')
text=[]
for c in cells:
    s=''.join(c['source'])
    text.append(('# %% [markdown]\n'+''.join('# '+line+'\n' for line in s.splitlines())) if c['cell_type']=='markdown' else '# %% CODE CELL\n'+s+'\n')
(ROOT/'copy_paste_cells.txt').write_text('\n'.join(text),encoding='utf-8')
print('Built standalone notebook and copy/paste cells')
