#!/usr/bin/env python3
import argparse, json, math
from collections import defaultdict
from pathlib import Path
import pandas as pd
import numpy as np

EDGES = np.array([-0.8, -0.4, 0.4, 0.8], dtype=float)

def bucket(x: float) -> int:
    return int(np.digitize([x], EDGES, right=False)[0])

def ceil_cent(x: float) -> float:
    return math.ceil((x - 1e-12) * 100.0) / 100.0

def kalshi_fee(q: float, p: float, coeff: float = 0.07) -> float:
    if coeff <= 0:
        return 0.0
    return ceil_cent(coeff * q * p * (1.0 - p))

def pnl_yes(q, entry, exit_bid, fee_coeff):
    return q * (exit_bid - entry) - kalshi_fee(q, entry, fee_coeff) - kalshi_fee(q, exit_bid, fee_coeff)

def pnl_no(q, entry, exit_bid, fee_coeff):
    return q * (exit_bid - entry) - kalshi_fee(q, entry, fee_coeff) - kalshi_fee(q, exit_bid, fee_coeff)

def simulate(df: pd.DataFrame, horizon=50, step=5, fee_coeff=0.0):
    spreads = df['spread'].astype(float).to_numpy()
    imbs = df['imb1'].astype(float).to_numpy()
    bid = df['bid'].astype(float).to_numpy()
    ask = df['ask'].astype(float).to_numpy()
    n = len(df)

    # Expanding 25th percentile, min 20 observations, causal including current observation.
    q25 = pd.Series(spreads).expanding(min_periods=20).quantile(0.25).to_numpy()

    anchors = []
    pending = []
    current_state = 0
    last_state_anchor = -1
    counts_b = defaultdict(lambda: [0,0,0])
    counts_bs = defaultdict(lambda: [0,0,0])

    # Process every trade observation. Resolve previous anchors before creating an anchor at i.
    for i in range(n):
        yes_bid = float(bid[i])
        yes_ask = float(ask[i])
        no_bid = 1.0 - yes_ask

        # First-passage resolution becomes observable immediately, but counts mature only at +horizon.
        for a in pending:
            if a['resolved_y'] is None and i > a['i']:
                yp = pnl_yes(1.0, a['yes_ask'], yes_bid, fee_coeff)
                npnl = pnl_no(1.0, a['no_ask'], no_bid, fee_coeff)
                if yp > 0 or npnl > 0:
                    a['resolved_y'] = 1 if yp >= npnl else -1
                    a['resolved_i'] = i
                    if a['i'] > last_state_anchor:
                        current_state = a['resolved_y']
                        last_state_anchor = a['i']

        # Mature after full horizon, including zeros. Mature before evaluating new anchor at same i.
        still = []
        for a in pending:
            if i >= a['i'] + horizon:
                y = 0 if a['resolved_y'] is None else int(a['resolved_y'])
                counts_b[a['bucket']][y+1] += 1
                counts_bs[(a['bucket'], a['state_at_anchor'])][y+1] += 1
                a['y'] = y
                a['mature_i'] = i
                anchors.append(a)
            else:
                still.append(a)
        pending = still

        if i % step != 0 or i + horizon >= n:
            continue
        if not np.isfinite(q25[i]):
            continue
        spread = float(spreads[i])
        imb = float(imbs[i])
        if abs(imb) < 0.8 or spread > float(q25[i]):
            continue
        pending.append({
            'i': i,
            'bucket': bucket(imb),
            'state_at_anchor': int(current_state),
            'yes_ask': float(ask[i]),
            'no_ask': float(1.0 - bid[i]),
            'resolved_y': None,
            'resolved_i': None,
        })

    return {
        'mature_anchors': len(anchors),
        'bucket_counts': {str(k): v for k,v in sorted(counts_b.items())},
        'bucket_state_counts': {f'{k[0]}|{k[1]}': v for k,v in sorted(counts_bs.items())},
        'label_counts': {
            '-1': sum(v[0] for v in counts_b.values()),
            '0': sum(v[1] for v in counts_b.values()),
            '+1': sum(v[2] for v in counts_b.values()),
        },
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('features_csv_gz')
    ap.add_argument('--out', default='kalshi_btc15m_fp_seed.json')
    args = ap.parse_args()
    df = pd.read_csv(args.features_csv_gz)
    required = {'bid','ask','imb1','spread'}
    missing = required - set(df.columns)
    if missing:
        raise SystemExit(f'Missing columns: {sorted(missing)}')
    gross = simulate(df, fee_coeff=0.0)
    net = simulate(df, fee_coeff=0.07)
    out = {
        'source': str(Path(args.features_csv_gz).name),
        'description': 'Historical KXBTC15M empirical first-passage distributions for live paper trading.',
        'rules': {
            'horizon_trades': 50,
            'candidate_every_trades': 5,
            'abs_imbalance_min': 0.8,
            'spread_filter': 'expanding 25th percentile, min 20 trade observations',
            'imbalance_bucket_edges': EDGES.tolist(),
            'state': 'latest-origin earlier anchor whose first passage is already observable; counts mature only after full 50-trade exposure',
            'smoothing': '(count + 0.5)/(cell_n + 1.5)',
            'gross_label': 'first future trade <=50 where YES or NO liquidation has positive gross PnL',
            'net_label': 'same but with general 0.07*p*(1-p) taker fee per leg, rounded up to cent',
        },
        'gross': gross,
        'net_general_fee': net,
    }
    Path(args.out).write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))

if __name__ == '__main__':
    main()
