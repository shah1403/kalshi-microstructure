#!/usr/bin/env python3
"""
Live Kalshi paper trader for the empirical first-passage microstructure strategy.

NO ORDERS ARE SENT. This script only subscribes to live market data and simulates PnL.

Model:
  - trade-time observations
  - L1 YES imbalance = (yes_bid_qty - yes_ask_qty)/(sum)
    where YES ask is implied from best NO bid
  - eligible anchors every 5 trades when |imbalance| >= 0.8 and spread <=
    expanding 25th percentile (minimum 20 observations)
  - Y in {-1,0,+1}: first gross (or configured net) favorable liquidation
    within 50 trades, with counts updating only after full 50-trade exposure
  - optional S_t = latest-origin prior anchor whose first passage is already observable
  - empirical smoothed probabilities (count + 0.5)/(cell_n + 1.5)

Execution simulation:
  - default 5 ms signal-to-entry latency
  - marketable entry at current YES/NO ask, top-of-book size checked
  - exit at first future trade where estimated net PnL > 0
  - otherwise force-liquidate at 50 trades
  - reports gross and fee-estimated net separately

The general Kalshi taker fee coefficient defaults to 0.07 and cent ceiling.
Some markets can have a different fee schedule. Override with --fee-coeff or --fee-quantum.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import csv
import json
import math
import os
import signal
import sys
import time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import requests
import websockets
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

WS_URL = "wss://external-api-ws.kalshi.com/trade-api/ws/v2"
WS_SIGN_PATH = "/trade-api/ws/v2"
REST_BASE = "https://external-api.kalshi.com/trade-api/v2"
EDGES = (-0.8, -0.4, 0.4, 0.8)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def to_float(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def bucket_of(x: float) -> int:
    if x < EDGES[0]:
        return 0
    if x < EDGES[1]:
        return 1
    if x < EDGES[2]:
        return 2
    if x < EDGES[3]:
        return 3
    return 4


def ceil_to_quantum(x: float, quantum: float) -> float:
    if x <= 0 or quantum <= 0:
        return max(0.0, x)
    return math.ceil((x - 1e-12) / quantum) * quantum


def kalshi_fee(q: float, p: float, coeff: float, quantum: float) -> float:
    if coeff <= 0:
        return 0.0
    raw = coeff * q * p * (1.0 - p)
    return ceil_to_quantum(raw, quantum)


class SpreadQuantile:
    """Exact empirical quantile for discretized dollar spreads using a histogram."""
    SCALE = 1_000_000

    def __init__(self):
        self.c = Counter()
        self.n = 0

    def add(self, spread: float):
        k = int(round(spread * self.SCALE))
        self.c[k] += 1
        self.n += 1

    def _kth(self, k: int) -> int:
        seen = 0
        for value in sorted(self.c):
            nxt = seen + self.c[value]
            if k < nxt:
                return value
            seen = nxt
        raise IndexError(k)

    def quantile(self, q: float) -> Optional[float]:
        if self.n == 0:
            return None
        h = (self.n - 1) * q
        lo = int(math.floor(h))
        hi = int(math.ceil(h))
        vlo = self._kth(lo)
        vhi = self._kth(hi)
        frac = h - lo
        return ((1 - frac) * vlo + frac * vhi) / self.SCALE


@dataclass
class BookView:
    yes_bid: float
    yes_bid_qty: float
    yes_ask: float
    yes_ask_qty: float
    no_bid: float
    no_bid_qty: float
    no_ask: float
    no_ask_qty: float

    @property
    def spread(self) -> float:
        return self.yes_ask - self.yes_bid

    @property
    def imbalance(self) -> float:
        den = self.yes_bid_qty + self.yes_ask_qty
        return (self.yes_bid_qty - self.yes_ask_qty) / den if den > 0 else 0.0


class KalshiBook:
    def __init__(self):
        self.yes: Dict[float, float] = {}
        self.no: Dict[float, float] = {}
        self.valid = False
        self.sid: Optional[int] = None
        self.seq: Optional[int] = None
        self.last_update_monotonic = 0.0

    @staticmethod
    def _levels(msg: dict, side: str):
        # Current fixed-point schema first; legacy aliases are accepted for robustness.
        return (
            msg.get(f"{side}_dollars_fp")
            or msg.get(f"{side}_dollars")
            or msg.get(side)
            or []
        )

    def snapshot(self, envelope: dict):
        msg = envelope.get("msg", {})
        self.yes.clear()
        self.no.clear()
        for p, q, *_ in self._levels(msg, "yes"):
            pf, qf = to_float(p), to_float(q)
            if pf is not None and qf is not None and qf > 0:
                # Very old schemas can send cents as integers.
                if pf > 1.0:
                    pf /= 100.0
                self.yes[pf] = qf
        for p, q, *_ in self._levels(msg, "no"):
            pf, qf = to_float(p), to_float(q)
            if pf is not None and qf is not None and qf > 0:
                if pf > 1.0:
                    pf /= 100.0
                self.no[pf] = qf
        self.sid = envelope.get("sid")
        self.seq = envelope.get("seq")
        self.valid = bool(self.yes and self.no)
        self.last_update_monotonic = time.monotonic()

    def delta(self, envelope: dict):
        if not self.valid:
            return
        sid = envelope.get("sid")
        seq = envelope.get("seq")
        if self.sid is not None and sid == self.sid and self.seq is not None and seq is not None:
            if int(seq) != int(self.seq) + 1:
                self.valid = False
                raise RuntimeError(f"orderbook sequence gap: expected {self.seq + 1}, got {seq}")
        self.sid, self.seq = sid, seq
        msg = envelope.get("msg", {})
        side = str(msg.get("side", "")).lower()
        p = to_float(msg.get("price_dollars", msg.get("price")))
        dq = to_float(msg.get("delta_fp", msg.get("delta")))
        if p is None or dq is None or side not in ("yes", "no"):
            return
        if p > 1.0:
            p /= 100.0
        levels = self.yes if side == "yes" else self.no
        q = levels.get(p, 0.0) + dq
        if q <= 1e-12:
            levels.pop(p, None)
        else:
            levels[p] = q
        self.valid = bool(self.yes and self.no)
        self.last_update_monotonic = time.monotonic()

    def view(self) -> Optional[BookView]:
        if not self.valid or not self.yes or not self.no:
            return None
        yb = max(self.yes)
        nb = max(self.no)
        ya = 1.0 - nb
        na = 1.0 - yb
        if yb <= 0 or nb <= 0 or ya <= yb or na <= nb:
            return None
        return BookView(
            yes_bid=yb,
            yes_bid_qty=self.yes[yb],
            yes_ask=ya,
            yes_ask_qty=self.no[nb],  # implied YES ask liquidity is the NO bid quantity
            no_bid=nb,
            no_bid_qty=self.no[nb],
            no_ask=na,
            no_ask_qty=self.yes[yb],
        )


class EmpiricalDistribution:
    def __init__(self, seed_path: Optional[str], label_mode: str):
        self.bucket_counts = defaultdict(lambda: [0, 0, 0])
        self.state_counts = defaultdict(lambda: [0, 0, 0])
        self.seed_meta = {}
        if seed_path:
            data = json.loads(Path(seed_path).read_text())
            key = "gross" if label_mode == "gross" else "net_general_fee"
            d = data[key]
            for k, v in d.get("bucket_counts", {}).items():
                self.bucket_counts[int(k)] = [int(x) for x in v]
            for k, v in d.get("bucket_state_counts", {}).items():
                b, s = k.split("|")
                self.state_counts[(int(b), int(s))] = [int(x) for x in v]
            self.seed_meta = {"source": data.get("source"), "mode": key, "anchors": d.get("mature_anchors")}

    @staticmethod
    def probs_from_counts(c: List[int]) -> Tuple[float, float, float, int]:
        n = int(sum(c))
        den = n + 1.5
        return ((c[0] + 0.5) / den, (c[1] + 0.5) / den, (c[2] + 0.5) / den, n)

    def probs(self, bucket: int, state: int, variant: str):
        c = self.bucket_counts[bucket] if variant == "imbalance" else self.state_counts[(bucket, state)]
        return self.probs_from_counts(c)

    def update(self, bucket: int, state_at_anchor: int, y: int):
        self.bucket_counts[bucket][y + 1] += 1
        self.state_counts[(bucket, state_at_anchor)][y + 1] += 1


@dataclass
class LabelAnchor:
    anchor_trade: int
    bucket: int
    state_at_anchor: int
    yes_ask: float
    no_ask: float
    resolved_y: Optional[int] = None
    resolved_trade: Optional[int] = None


class OnlineLabeler:
    def __init__(self, dist: EmpiricalDistribution, horizon: int, label_mode: str,
                 fee_coeff: float, fee_quantum: float):
        self.dist = dist
        self.horizon = horizon
        self.label_mode = label_mode
        self.fee_coeff = fee_coeff
        self.fee_quantum = fee_quantum
        self.pending: List[LabelAnchor] = []
        self.current_state = 0
        self.latest_resolved_origin = -1
        self.matured_live = 0
        self.live_label_counts = Counter()

    def _label_pnl(self, side: int, entry: float, exit_bid: float) -> float:
        gross = exit_bid - entry
        if self.label_mode == "gross":
            return gross
        return gross - kalshi_fee(1, entry, self.fee_coeff, self.fee_quantum) - kalshi_fee(1, exit_bid, self.fee_coeff, self.fee_quantum)

    def on_trade(self, trade_no: int, book: BookView):
        # Resolve as soon as a first passage is observable.
        for a in self.pending:
            if a.resolved_y is not None or trade_no <= a.anchor_trade:
                continue
            yp = self._label_pnl(+1, a.yes_ask, book.yes_bid)
            npnl = self._label_pnl(-1, a.no_ask, book.no_bid)
            if yp > 0 or npnl > 0:
                a.resolved_y = +1 if yp >= npnl else -1
                a.resolved_trade = trade_no
                if a.anchor_trade > self.latest_resolved_origin:
                    self.latest_resolved_origin = a.anchor_trade
                    self.current_state = a.resolved_y

        # Mature only after complete 50-trade exposure.
        keep = []
        for a in self.pending:
            if trade_no >= a.anchor_trade + self.horizon:
                y = 0 if a.resolved_y is None else int(a.resolved_y)
                self.dist.update(a.bucket, a.state_at_anchor, y)
                self.matured_live += 1
                self.live_label_counts[y] += 1
            else:
                keep.append(a)
        self.pending = keep

    def add_anchor(self, trade_no: int, bucket: int, book: BookView):
        self.pending.append(LabelAnchor(
            anchor_trade=trade_no,
            bucket=bucket,
            state_at_anchor=int(self.current_state),
            yes_ask=book.yes_ask,
            no_ask=book.no_ask,
        ))


@dataclass
class Position:
    side: int
    q: float
    anchor_trade: int
    entry_trade: int
    entry_price: float
    entry_fee: float
    signal_pminus: float
    signal_pzero: float
    signal_pplus: float
    bucket: int
    state: int


class PaperStrategy:
    def __init__(self, name: str, variant: str, policy: str, q: float, horizon: int,
                 latency_ms: float, fee_coeff: float, fee_quantum: float):
        self.name = name
        self.variant = variant
        self.policy = policy
        self.q = q
        self.horizon = horizon
        self.latency_ms = latency_ms
        self.fee_coeff = fee_coeff
        self.fee_quantum = fee_quantum
        self.position: Optional[Position] = None
        self.pending_entry: Optional[dict] = None
        self.gross_cash = 0.0
        self.net_cash = 0.0
        self.closed = 0
        self.wins_net = 0
        self.signals = 0
        self.abstains = 0
        self.unfilled = 0

    def choose_side(self, pminus, pzero, pplus) -> int:
        if self.policy == "ternary" and pzero >= max(pminus, pplus):
            return 0
        if pplus > pminus:
            return +1
        if pminus > pplus:
            return -1
        return 0

    def signal(self, trade_no: int, probs, bucket: int, state: int):
        if self.position is not None or self.pending_entry is not None:
            return
        pminus, pzero, pplus, cell_n = probs
        side = self.choose_side(pminus, pzero, pplus)
        self.signals += 1
        if side == 0:
            self.abstains += 1
            return
        self.pending_entry = {
            "side": side,
            "anchor_trade": trade_no,
            "due": time.monotonic() + self.latency_ms / 1000.0,
            "pminus": pminus, "pzero": pzero, "pplus": pplus,
            "bucket": bucket, "state": state, "cell_n": cell_n,
        }

    def maybe_fill(self, trade_no: int, book: BookView):
        pe = self.pending_entry
        if pe is None:
            return None
        if trade_no >= pe["anchor_trade"] + self.horizon:
            self.pending_entry = None
            self.unfilled += 1
            return None
        if time.monotonic() < pe["due"]:
            return None
        side = pe["side"]
        price = book.yes_ask if side == +1 else book.no_ask
        depth = book.yes_ask_qty if side == +1 else book.no_ask_qty
        if depth + 1e-12 < self.q:
            # Keep pending until a later update or the horizon.
            return None
        fee = kalshi_fee(self.q, price, self.fee_coeff, self.fee_quantum)
        self.position = Position(
            side=side, q=self.q, anchor_trade=pe["anchor_trade"], entry_trade=trade_no,
            entry_price=price, entry_fee=fee,
            signal_pminus=pe["pminus"], signal_pzero=pe["pzero"], signal_pplus=pe["pplus"],
            bucket=pe["bucket"], state=pe["state"],
        )
        self.pending_entry = None
        return {"event": "OPEN", "strategy": self.name, "side": "YES" if side == 1 else "NO",
                "price": price, "q": self.q, "anchor_trade": self.position.anchor_trade,
                "entry_trade": trade_no, "entry_fee": fee}

    def mark(self, trade_no: int, book: BookView):
        p = self.position
        if p is None:
            return None
        exit_price = book.yes_bid if p.side == +1 else book.no_bid
        depth = book.yes_bid_qty if p.side == +1 else book.no_bid_qty
        if depth + 1e-12 < p.q:
            return None
        gross = p.q * (exit_price - p.entry_price)
        exit_fee = kalshi_fee(p.q, exit_price, self.fee_coeff, self.fee_quantum)
        net = gross - p.entry_fee - exit_fee
        deadline = trade_no >= p.anchor_trade + self.horizon
        if net <= 0 and not deadline:
            return None
        reason = "profit" if net > 0 else "timeout"
        self.gross_cash += gross
        self.net_cash += net
        self.closed += 1
        self.wins_net += int(net > 0)
        rec = {
            "event": "CLOSE", "strategy": self.name,
            "side": "YES" if p.side == 1 else "NO", "q": p.q,
            "anchor_trade": p.anchor_trade, "entry_trade": p.entry_trade,
            "exit_trade": trade_no, "wait_trades": trade_no - p.anchor_trade,
            "entry": p.entry_price, "exit": exit_price,
            "gross": gross, "entry_fee": p.entry_fee, "exit_fee": exit_fee,
            "net": net, "gross_cash": self.gross_cash, "net_cash": self.net_cash,
            "reason": reason, "pminus": p.signal_pminus, "pzero": p.signal_pzero,
            "pplus": p.signal_pplus, "bucket": p.bucket, "state": p.state,
        }
        self.position = None
        return rec


class CsvLog:
    def __init__(self, path: Path, fields: List[str]):
        self.path = path
        self.f = path.open("a", newline="", buffering=1)
        self.w = csv.DictWriter(self.f, fieldnames=fields, extrasaction="ignore")
        if path.stat().st_size == 0:
            self.w.writeheader()

    def write(self, row: dict):
        self.w.writerow(row)

    def close(self):
        self.f.close()


def sign_headers(key_id: str, private_key, method: str, path: str) -> dict:
    ts = str(int(time.time() * 1000))
    text = (ts + method.upper() + path.split("?")[0]).encode()
    sig = private_key.sign(
        text,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
        hashes.SHA256(),
    )
    return {
        "KALSHI-ACCESS-KEY": key_id,
        "KALSHI-ACCESS-TIMESTAMP": ts,
        "KALSHI-ACCESS-SIGNATURE": base64.b64encode(sig).decode(),
    }


def discover_btc15m() -> str:
    r = requests.get(
        REST_BASE + "/markets",
        params={"series_ticker": "KXBTC15M", "status": "open", "limit": 100},
        timeout=10,
    )
    r.raise_for_status()
    markets = r.json().get("markets", [])
    if not markets:
        raise RuntimeError("No open KXBTC15M market found. Pass --ticker explicitly.")
    def close_key(m):
        return m.get("close_time") or m.get("expected_expiration_time") or "9999"
    markets.sort(key=close_key)
    return markets[0]["ticker"]


def format_probs(probs):
    pm, p0, pp, n = probs
    return f"P-/0/+={pm:.3f}/{p0:.3f}/{pp:.3f} n={n}"


class LiveApp:
    def __init__(self, args, ticker, private_key):
        self.args = args
        self.ticker = ticker
        self.private_key = private_key
        self.book = KalshiBook()
        self.dist = EmpiricalDistribution(args.seed, args.label_mode)
        self.labeler = OnlineLabeler(self.dist, args.horizon, args.label_mode, args.fee_coeff, args.fee_quantum)
        self.spreads = SpreadQuantile()
        self.trade_no = 0
        self.seen_trades = set()
        self.stop = False
        self.last_heartbeat = 0
        self.outdir = Path(args.outdir)
        self.outdir.mkdir(parents=True, exist_ok=True)
        policies = [args.policy] if args.policy != "both" else ["direction", "ternary"]
        self.strategies = []
        for variant in ("imbalance", "state"):
            for policy in policies:
                self.strategies.append(PaperStrategy(
                    f"{variant}:{policy}", variant, policy, args.q, args.horizon,
                    args.latency_ms, args.fee_coeff, args.fee_quantum,
                ))
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.predlog = CsvLog(self.outdir / f"predictions_{ticker}_{stamp}.csv", [
            "utc","ticker","trade_no","yes_bid","yes_ask","bq","aq","spread","q25","imbalance","bucket","state",
            "variant","pminus","pzero","pplus","cell_n","policy","action"
        ])
        self.tradelog = CsvLog(self.outdir / f"paper_trades_{ticker}_{stamp}.csv", [
            "utc","ticker","event","strategy","side","q","anchor_trade","entry_trade","exit_trade","wait_trades",
            "entry","exit","gross","entry_fee","exit_fee","net","gross_cash","net_cash","reason","pminus","pzero","pplus","bucket","state"
        ])
        self.rawlog = (self.outdir / f"raw_ws_{ticker}_{stamp}.jsonl").open("a", buffering=1) if args.log_raw else None

    def close(self):
        self.predlog.close(); self.tradelog.close()
        if self.rawlog: self.rawlog.close()

    def quote_ok(self) -> bool:
        return self.book.valid and (time.monotonic() - self.book.last_update_monotonic) * 1000 <= self.args.max_quote_age_ms

    def all_strategy_summary(self) -> str:
        bits=[]
        for s in self.strategies:
            bits.append(f"{s.name} closed={s.closed} gross={s.gross_cash:+.4f} net={s.net_cash:+.4f}")
        return " | ".join(bits)

    def try_fills(self):
        view = self.book.view()
        if view is None or not self.quote_ok():
            return
        for s in self.strategies:
            rec = s.maybe_fill(self.trade_no, view)
            if rec:
                rec.update({"utc": now_iso(), "ticker": self.ticker})
                self.tradelog.write(rec)
                print(f"  {s.name} OPEN {rec['side']} @{rec['price']:.4f} q={rec['q']} fee≈{rec['entry_fee']:.4f}")

    def on_book_snapshot(self, d):
        self.book.snapshot(d)
        self.try_fills()

    def on_book_delta(self, d):
        self.book.delta(d)
        self.try_fills()

    def on_trade(self, d):
        msg = d.get("msg", {})
        ticker = msg.get("market_ticker") or msg.get("ticker")
        if ticker and ticker != self.ticker:
            return
        if msg.get("is_block_trade") is True:
            return
        tid = str(msg.get("trade_id") or "")
        if tid and tid in self.seen_trades:
            return
        if tid:
            self.seen_trades.add(tid)
            if len(self.seen_trades) > 200_000:
                # Enough for reconnect dedup in a 15-minute contract without unbounded memory.
                self.seen_trades = set(list(self.seen_trades)[-100_000:])
        view = self.book.view()
        if view is None or not self.quote_ok():
            return

        self.trade_no += 1
        self.spreads.add(view.spread)
        self.labeler.on_trade(self.trade_no, view)

        # Fill pending entries after latency, then mark open positions on this trade.
        self.try_fills()
        for s in self.strategies:
            rec = s.mark(self.trade_no, view)
            if rec:
                rec.update({"utc": now_iso(), "ticker": self.ticker})
                self.tradelog.write(rec)
                print(f"  {s.name} CLOSE {rec['reason']} gross={rec['gross']:+.4f} net={rec['net']:+.4f} cash={rec['net_cash']:+.4f}")

        q25 = self.spreads.quantile(0.25) if self.spreads.n >= 20 else None
        eligible = (
            self.trade_no % self.args.candidate_every == 0
            and q25 is not None
            and abs(view.imbalance) >= self.args.min_abs_imb
            and view.spread <= q25 + 1e-12
        )
        if eligible:
            b = bucket_of(view.imbalance)
            st = int(self.labeler.current_state)
            p_imb = self.dist.probs(b, st, "imbalance")
            p_st = self.dist.probs(b, st, "state")
            print(f"\n[{now_iso()}] trade={self.trade_no} {self.ticker} YES {view.yes_bid:.4f}/{view.yes_ask:.4f} "
                  f"I={view.imbalance:+.3f} spread={view.spread:.4f} q25={q25:.4f} S={st}")
            print("  imbalance  ", format_probs(p_imb))
            print("  imbalance+S", format_probs(p_st))

            # Label anchor is created regardless of whether paper strategy is already in a position.
            self.labeler.add_anchor(self.trade_no, b, view)

            for s in self.strategies:
                probs = p_imb if s.variant == "imbalance" else p_st
                side = s.choose_side(*probs[:3])
                action = "YES" if side == 1 else "NO" if side == -1 else "ABSTAIN"
                self.predlog.write({
                    "utc": now_iso(), "ticker": self.ticker, "trade_no": self.trade_no,
                    "yes_bid": view.yes_bid, "yes_ask": view.yes_ask, "bq": view.yes_bid_qty, "aq": view.yes_ask_qty,
                    "spread": view.spread, "q25": q25, "imbalance": view.imbalance, "bucket": b, "state": st,
                    "variant": s.variant, "pminus": probs[0], "pzero": probs[1], "pplus": probs[2], "cell_n": probs[3],
                    "policy": s.policy, "action": action,
                })
                s.signal(self.trade_no, probs, b, st)
            print("  " + self.all_strategy_summary())

        if self.trade_no - self.last_heartbeat >= self.args.heartbeat_trades:
            self.last_heartbeat = self.trade_no
            print(f"[{now_iso()}] heartbeat trades={self.trade_no} I={view.imbalance:+.3f} " + self.all_strategy_summary())

    async def connect_once(self):
        headers = sign_headers(self.args.key_id, self.private_key, "GET", WS_SIGN_PATH)
        kwargs = {"ping_interval": 10, "ping_timeout": 20, "close_timeout": 5, "max_queue": 8192}
        # websockets >=14 uses additional_headers. Older versions use extra_headers.
        try:
            ws_ctx = websockets.connect(WS_URL, additional_headers=headers, **kwargs)
        except TypeError:
            ws_ctx = websockets.connect(WS_URL, extra_headers=headers, **kwargs)
        async with ws_ctx as ws:
            print(f"Connected to Kalshi. Subscribing to {self.ticker}...")
            await ws.send(json.dumps({
                "id": 1, "cmd": "subscribe",
                "params": {"channels": ["orderbook_delta"], "market_ticker": self.ticker},
            }))
            await ws.send(json.dumps({
                "id": 2, "cmd": "subscribe",
                "params": {"channels": ["trade"], "market_ticker": self.ticker},
            }))
            async for raw in ws:
                if self.rawlog:
                    self.rawlog.write(raw + "\n")
                d = json.loads(raw)
                typ = d.get("type")
                if typ == "orderbook_snapshot":
                    self.on_book_snapshot(d)
                elif typ == "orderbook_delta":
                    self.on_book_delta(d)
                elif typ == "trade":
                    self.on_trade(d)
                elif typ == "subscribed":
                    print("Subscribed:", d.get("msg", d))
                elif typ == "error":
                    raise RuntimeError(f"Kalshi websocket error: {d}")
                if self.stop:
                    break

    async def run(self):
        print("PAPER ONLY. No Kalshi orders are sent.")
        print("Ticker:", self.ticker)
        print("Seed:", self.dist.seed_meta or "none")
        print(f"Rules: horizon={self.args.horizon} trades, candidate_every={self.args.candidate_every}, "
              f"latency={self.args.latency_ms}ms, q={self.args.q}, label_mode={self.args.label_mode}")
        print(f"Fee estimate: coeff={self.args.fee_coeff}, rounding quantum=${self.args.fee_quantum:.4f} per order")
        backoff = 1
        while not self.stop:
            try:
                await self.connect_once()
                backoff = 1
            except asyncio.CancelledError:
                break
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Connection/replay error: {e}", file=sys.stderr)
                if self.stop:
                    break
                await asyncio.sleep(backoff)
                backoff = min(30, backoff * 2)
        print("Final:", self.all_strategy_summary())
        print("Live matured labels:", dict(self.labeler.live_label_counts))


def parse_args():
    ap = argparse.ArgumentParser(description="Kalshi live first-passage paper PnL monitor")
    ap.add_argument("--key-id", default=os.getenv("KALSHI_KEY_ID"), help="Kalshi API key ID; or set KALSHI_KEY_ID")
    ap.add_argument("--private-key", default=os.getenv("KALSHI_PRIVATE_KEY_PATH"), help="PEM path; or set KALSHI_PRIVATE_KEY_PATH")
    ap.add_argument("--ticker", default="auto", help="Kalshi market ticker, or 'auto' for nearest open KXBTC15M")
    ap.add_argument("--seed", default=str(Path(__file__).with_name("kalshi_btc15m_fp_seed.json")), help="Historical seed JSON")
    ap.add_argument("--label-mode", choices=["gross", "net"], default="gross",
                    help="Outcome distribution label: gross first passage (default) or fee-aware")
    ap.add_argument("--policy", choices=["direction", "ternary", "both"], default="both")
    ap.add_argument("--horizon", type=int, default=50)
    ap.add_argument("--candidate-every", type=int, default=5)
    ap.add_argument("--min-abs-imb", type=float, default=0.8)
    ap.add_argument("--latency-ms", type=float, default=5.0)
    ap.add_argument("--q", type=float, default=1.0)
    ap.add_argument("--fee-coeff", type=float, default=0.07,
                    help="Estimated taker fee coefficient. General-event default is 0.07; market-specific fees can differ.")
    ap.add_argument("--fee-quantum", type=float, default=0.01,
                    help="Fee rounding quantum in dollars. Default conservative cent ceiling.")
    ap.add_argument("--max-quote-age-ms", type=float, default=1000.0)
    ap.add_argument("--heartbeat-trades", type=int, default=50)
    ap.add_argument("--outdir", default="kalshi_live_output")
    ap.add_argument("--log-raw", action="store_true")
    return ap.parse_args()


def main():
    args = parse_args()
    if not args.key_id:
        raise SystemExit("Missing --key-id or KALSHI_KEY_ID")
    if not args.private_key:
        raise SystemExit("Missing --private-key or KALSHI_PRIVATE_KEY_PATH")
    key_bytes = Path(args.private_key).read_bytes()
    private_key = serialization.load_pem_private_key(key_bytes, password=None)
    ticker = discover_btc15m() if args.ticker.lower() == "auto" else args.ticker
    app = LiveApp(args, ticker, private_key)

    def request_stop(*_):
        app.stop = True
    try:
        signal.signal(signal.SIGINT, request_stop)
        signal.signal(signal.SIGTERM, request_stop)
    except Exception:
        pass
    try:
        asyncio.run(app.run())
    finally:
        app.close()


if __name__ == "__main__":
    main()
