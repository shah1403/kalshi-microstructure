import json, itertools, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import log_loss, brier_score_loss, roc_auc_score, average_precision_score, accuracy_score, mean_absolute_error

warnings.filterwarnings('ignore')
ROOT=Path('conditional_search'); ROOT.mkdir(exist_ok=True)
MARKETS={'NFL':('sports_v4/NFL/features.csv.gz','2026-09-13T20:26:00Z'),
         'MLB':('sports_v4/MLB/features.csv.gz','2026-09-10T20:12:00Z')}

def build(name,path,start):
 d=pd.read_csv(path); d['clock']=d.t-pd.Timestamp(start).timestamp()
 # One observation per elapsed second. This limits overlap and prevents bursts from dominating.
 sec=np.arange(60,int(d.clock.max())-31); ix=np.searchsorted(d.clock.to_numpy(),sec,side='right')-1
 x=d.iloc[ix].copy().reset_index(drop=True); x['clock']=sec; m=d.mid.to_numpy(); tt=d.clock.to_numpy()
 # Extra feature families, all computed using information available at decision time.
 x['log_bq']=np.log1p(x.bq); x['log_aq']=np.log1p(x.aq); x['log_dt']=np.log1p(x.dt)
 x['depth_skew']=(x.bq-x.aq)/(x.bq+x.aq+1e-9); x['depletion_scaled']=x.depletion/(x.bq+x.aq+1)
 x['buy_sell_1']=x.buy1-x.sell1; x['buy_sell_10']=x.buy10-x.sell10; x['buy_sell_60']=x.buy60-x.sell60
 for w in [20,100,500]:
  x[f'vol_{w}']=x.mid.rolling(w,min_periods=5).std().fillna(0)
  x[f'ret_{w}s']=x.mid-x.mid.shift(w).fillna(x.mid.iloc[0])
  x[f'range_{w}']=x.mid.rolling(w,min_periods=5).max()-x.mid.rolling(w,min_periods=5).min()
 x['bounce_20']=x.mid.diff().ne(0).rolling(20,min_periods=1).sum()
 # Counts and burst ratios on the original event clock.
 for w in [1,5,30,60]:
  x[f'trade_rate_{w}']=(np.searchsorted(tt,sec,side='right')-np.searchsorted(tt,sec-w,side='left'))/w
 x['burst_1_30']=x.trade_rate_1/(x.trade_rate_30+1e-3); x['burst_5_60']=x.trade_rate_5/(x.trade_rate_60+1e-3)
 # Previous first-passage move times are past-only and used as temporal/macro state.
 change=np.r_[False,np.abs(np.diff(m))>d.spread.to_numpy()[:-1]+1e-9]; move_t=tt[change]
 pos=np.searchsorted(move_t,sec,side='right'); last=np.where(pos>0,move_t[np.maximum(pos-1,0)],-1e6)
 x['since_big_move']=np.minimum(sec-last,1000)
 for w in [10,60,300]:x[f'big_move_rate_{w}']=(pos-np.searchsorted(move_t,sec-w,side='left'))/w
 x['progress']=sec/sec.max(); x['market']=name
 # First passage labels from the decision midpoint. Scan up to 30 seconds.
 for H in [1,5,30]:
  moved=[]; direction=[]; wait_s=[]; wait_n=[]
  for q,j in zip(sec,ix):
   end=np.searchsorted(tt,q+H,side='right'); future=m[j+1:end]; hit=np.flatnonzero(np.abs(future-m[j])>d.spread.iloc[j]+1e-9)
   if len(hit):
    k=j+1+hit[0]; moved.append(1); direction.append(int(m[k]>m[j])); wait_s.append(tt[k]-q); wait_n.append(k-j)
   else:moved.append(0); direction.append(np.nan); wait_s.append(H); wait_n.append(end-j-1)
  x[f'move_{H}s']=moved; x[f'dir_{H}s']=direction; x[f'wait_{H}s']=wait_s; x[f'waitn_{H}s']=wait_n
 return x

allx=pd.concat([build(k,*v) for k,v in MARKETS.items()],ignore_index=True)
families={
 'book':['imb1','imb5','log_bq','log_aq','depth','spread','depth_skew','depletion_scaled'],
 'flow':['sign','volume','flow5','flow20','flow50','buy_sell_1','buy_sell_10','buy_sell_60'],
 'temporal':['log_dt','trade_rate_1','trade_rate_5','trade_rate_30','trade_rate_60','burst_1_30','burst_5_60','since_big_move','big_move_rate_10','big_move_rate_60'],
 'state':['lag1','lag2','ret5','ret20','ret50','bounce_20'],
 'macro':['mid','progress','vol_20','vol_100','vol_500','ret_20s','ret_100s','ret_500s','range_20','range_100','range_500','big_move_rate_300']}
json.dump(families,open(ROOT/'feature_families.json','w'),indent=2)
# Fixed chronological 60/20/20 splits within each market.
allx['part']='';
for mk,g in allx.groupby('market'):
 a,b=np.quantile(g.clock,[.6,.8]); allx.loc[g.index[ g.clock<=a],'part']='train';allx.loc[g.index[(g.clock>a)&(g.clock<=b)],'part']='val';allx.loc[g.index[g.clock>b],'part']='test'
 allx.loc[g.index,'cut60']=a; allx.loc[g.index,'cut80']=b

combos=[]
keys=list(families)
for r in range(1,len(keys)+1):
 for c in itertools.combinations(keys,r):combos.append(c)

rows=[]; fitted={}
for H in [1,5,30]:
 for task in ['move','direction']:
  ycol=f'move_{H}s' if task=='move' else f'dir_{H}s'
  usable=allx[ycol].notna()
  for combo in combos:
   cols=sum((families[k] for k in combo),[]); key='+'.join(combo)
   for model in ['linear','tree']:
    # Purge decisions whose label window crosses a split boundary.
    tr=(allx.part=='train')&usable&(allx.clock<=allx.cut60-H)
    va=(allx.part=='val')&usable&(allx.clock<=allx.cut80-H)
    te=(allx.part=='test')&usable
    if min(allx.loc[tr,ycol].nunique(),allx.loc[va,ycol].nunique(),allx.loc[te,ycol].nunique())<2:continue
    if model=='linear':clf=make_pipeline(SimpleImputer(),StandardScaler(),LogisticRegression(C=.1,max_iter=1000,class_weight=None))
    else:clf=make_pipeline(SimpleImputer(),HistGradientBoostingClassifier(max_depth=3,max_iter=100,learning_rate=.05,l2_regularization=2,min_samples_leaf=30,random_state=19))
    clf.fit(allx.loc[tr,cols],allx.loc[tr,ycol].astype(int)); pv=clf.predict_proba(allx.loc[va,cols])[:,1]; pt=clf.predict_proba(allx.loc[te,cols])[:,1]
    for split,mask,p in [('val',va,pv),('test',te,pt)]:
     y=allx.loc[mask,ycol].astype(int).to_numpy(); base=np.repeat(allx.loc[tr,ycol].mean(),len(y))
     rows.append(dict(horizon=H,task=task,families=key,model=model,split=split,n=len(y),positive_rate=y.mean(),logloss=log_loss(y,p),baseline_logloss=log_loss(y,base),brier=brier_score_loss(y,p),baseline_brier=brier_score_loss(y,base),roc_auc=roc_auc_score(y,p),average_precision=average_precision_score(y,p)))
res=pd.DataFrame(rows);res.to_csv(ROOT/'all_family_combinations.csv',index=False)

# Select only on validation, report its locked test performance and a simple time-to-event model.
selected=[]
for (H,task),g in res[res.split=='val'].groupby(['horizon','task']):
 best=g.sort_values('logloss').iloc[0]; test=res[(res.horizon==H)&(res.task==task)&(res.families==best.families)&(res.model==best.model)&(res.split=='test')].iloc[0]
 selected.append({**test.to_dict(),'validation_logloss':best.logloss})
pd.DataFrame(selected).to_csv(ROOT/'selected_test_results.csv',index=False)

# Performance by market for the locked selections. This exposes market-specific effects.
detail=[]
for s in selected:
 H=int(s['horizon']); task=s['task']; ycol=f'move_{H}s' if task=='move' else f'dir_{H}s'; cols=sum((families[k] for k in s['families'].split('+')),[])
 usable=allx[ycol].notna(); tr=(allx.part=='train')&usable&(allx.clock<=allx.cut60-H); va=(allx.part=='val')&usable&(allx.clock<=allx.cut80-H)
 if s['model']=='linear':clf=make_pipeline(SimpleImputer(),StandardScaler(),LogisticRegression(C=.1,max_iter=1000))
 else:clf=make_pipeline(SimpleImputer(),HistGradientBoostingClassifier(max_depth=3,max_iter=100,learning_rate=.05,l2_regularization=2,min_samples_leaf=30,random_state=19))
 clf.fit(allx.loc[tr,cols],allx.loc[tr,ycol].astype(int))
 for mk in MARKETS:
  te=(allx.part=='test')&usable&(allx.market==mk); y=allx.loc[te,ycol].astype(int).to_numpy(); p=clf.predict_proba(allx.loc[te,cols])[:,1]; base=np.repeat(allx.loc[tr,ycol].mean(),len(y))
  detail.append(dict(horizon=H,task=task,market=mk,families=s['families'],model=s['model'],n=len(y),positive_rate=y.mean(),logloss=log_loss(y,p),baseline_logloss=log_loss(y,base),roc_auc=roc_auc_score(y,p),average_precision=average_precision_score(y,p)))
pd.DataFrame(detail).to_csv(ROOT/'selected_by_market.csv',index=False)

# Conditional descriptive tests requested: imbalance/activity bins -> chance and median wait.
desc=[]
for mk,g in allx[allx.part=='test'].groupby('market'):
 for H in [5,30]:
  for feature in ['imb1','imb5','flow20','burst_1_30','since_big_move','big_move_rate_60']:
   bins=pd.qcut(g[feature],5,duplicates='drop')
   for b,z in g.groupby(bins,observed=True):
    movers=z[z[f'move_{H}s']==1]
    desc.append(dict(market=mk,horizon=H,condition=feature,bin=str(b),n=len(z),move_rate=z[f'move_{H}s'].mean(),median_wait_seconds=movers[f'wait_{H}s'].median() if len(movers) else np.nan,up_given_move=movers[f'dir_{H}s'].mean() if len(movers) else np.nan))
pd.DataFrame(desc).to_csv(ROOT/'conditional_bins.csv',index=False)

# Direct restricted-time forecasts: min(time to first passage, 30 seconds/trades).
waitrows=[]
for target in ['wait_30s','waitn_30s']:
 for combo in combos:
  cols=sum((families[k] for k in combo),[]); key='+'.join(combo)
  for model in ['linear','tree']:
   tr=(allx.part=='train')&(allx.clock<=allx.cut60-30); va=(allx.part=='val')&(allx.clock<=allx.cut80-30); te=allx.part=='test'
   reg=make_pipeline(SimpleImputer(),StandardScaler(),Ridge(alpha=10)) if model=='linear' else make_pipeline(SimpleImputer(),HistGradientBoostingRegressor(max_depth=3,max_iter=100,learning_rate=.05,l2_regularization=2,min_samples_leaf=30,random_state=19))
   reg.fit(allx.loc[tr,cols],allx.loc[tr,target]); base=allx.loc[tr,target].median()
   for split,mask in [('val',va),('test',te)]:
    y=allx.loc[mask,target].to_numpy(); p=reg.predict(allx.loc[mask,cols]); waitrows.append(dict(target=target,families=key,model=model,split=split,n=len(y),mae=mean_absolute_error(y,p),baseline_mae=mean_absolute_error(y,np.repeat(base,len(y)))))
wr=pd.DataFrame(waitrows);wr.to_csv(ROOT/'wait_time_family_combinations.csv',index=False)
wsel=[]
for target,g in wr[wr.split=='val'].groupby('target'):
 best=g.sort_values('mae').iloc[0]; test=wr[(wr.target==target)&(wr.families==best.families)&(wr.model==best.model)&(wr.split=='test')].iloc[0];wsel.append({**test.to_dict(),'validation_mae':best.mae})
pd.DataFrame(wsel).to_csv(ROOT/'selected_wait_results.csv',index=False)

# Two-dimensional conditional tables across feature classes.
pairs=[('imb5','burst_1_30'),('imb5','flow20'),('flow20','since_big_move'),('imb5','since_big_move')]; pairrows=[]
for mk,g in allx[allx.part=='test'].groupby('market'):
 for a,b in pairs:
  qa=pd.qcut(g[a],4,labels=False,duplicates='drop'); qb=pd.qcut(g[b],4,labels=False,duplicates='drop')
  for (ia,ib),z in g.groupby([qa,qb]):
   movers=z[z.move_30s==1];pairrows.append(dict(market=mk,feature_a=a,feature_b=b,bin_a=int(ia),bin_b=int(ib),n=len(z),move_30s=z.move_30s.mean(),median_wait_30s=movers.wait_30s.median() if len(movers) else np.nan,up_given_move=movers.dir_30s.mean() if len(movers) else np.nan))
pd.DataFrame(pairrows).to_csv(ROOT/'pair_condition_tables.csv',index=False)
allx.to_csv(ROOT/'modeling_dataset.csv.gz',index=False,compression='gzip')
print(pd.DataFrame(selected).to_string(index=False))
