# Conditional Kalshi feature search

## Result

The tested features predict **whether a spread-clearing move will happen soon**, especially over 1 and 5 seconds. They do not produce a stable prediction of **which direction the move will take**. This is a timing or conditional-hazard edge in these two recordings, not yet an executable trading edge.

The movement label is a first passage from the midpoint at decision time. A move occurs when a later midpoint differs from the decision midpoint by more than the decision-time spread. This replaces the earlier one-trade label, which required the entire displacement in one trade and was excessively sparse.

Observations are sampled once per elapsed second. Each market is split chronologically into 60% training, 20% validation and 20% locked test data. Label windows crossing a split boundary are purged. The validation split selects one of 31 feature-family combinations and either a regularized linear or shallow nonlinear model. Test results are then reported without reselecting the model.

## Feature classes

| Class | Variables |
|---|---|
| Book microstructure | L1/L5 imbalance, bid/ask depth, spread, depth skew, depletion |
| Trade flow | aggressor sign and size, signed flow over 5/20/50 trades, buy/sell activity over 1/10/60 seconds |
| Temporal | intertrade duration, trade rates over 1/5/30/60 seconds, burst ratios, time since a large move, recent large-move rates |
| State history | previous ternary states, short returns, recent quote-change count |
| Macrostructure | contract price, longer returns, volatility and range over 20/100/500 seconds, game-time progress |

“Macrostructure” here means slower structure inside the individual contract recording. It does not include external news, the sports score, settlement probability, or correlated markets.

## Locked test performance

Lower log loss is better. The baseline uses the training-set event frequency.

| Target | Selected families | Test events | Model log loss | Baseline | ROC AUC |
|---|---|---:|---:|---:|---:|
| Move within 1s | book + flow + temporal | 51 / 3,888 | 0.0542 | 0.0758 | 0.908 |
| Move within 5s | book + temporal | 299 / 3,888 | 0.2193 | 0.3030 | 0.857 |
| Move within 30s | book + temporal + state | 1,351 / 3,888 | 0.6915 | 0.7350 | 0.650 |
| Up, conditional on move within 1s | flow | 26 / 51 | 0.7581 | 0.6948 | 0.503 |
| Up, conditional on move within 5s | temporal | 164 / 299 | 0.7979 | 0.6971 | 0.519 |
| Up, conditional on move within 30s | all families | 689 / 1,351 | 0.8008 | 0.6946 | 0.539 |

The timing results also improve log loss separately in both games. At 5 seconds, ROC AUC is 0.863 in NFL and 0.925 in MLB. At 1 second it is 0.917 and 0.913 respectively. Average precision remains modest because short-horizon moves are rare.

A market-aware block bootstrap resampled 60-second blocks. Model-minus-baseline log-loss differences were -0.0215 at 1 second, with a 95% interval of [-0.0332, -0.0108], and -0.0836 at 5 seconds, with [-0.1205, -0.0504]. Negative is better. The 30-second interval [-0.1190, 0.0326] includes zero. These intervals address short-range dependence but are based on only two markets and should not be treated as universal confidence intervals.

For direction, the selected 5- and 30-second models were significantly worse in the same block diagnostic. The apparent directional relationships found in individual bins or after ranking models by test performance are therefore exploratory data-mining results, not a validated signal.

## Conditional relationships

Two-dimensional test tables combine variables from different classes. In NFL, the empirical 30-second move rate ranged from 10.9% to 98.2% across sufficiently populated imbalance-by-time-since-move cells. In MLB, it ranged from 0% to 86.2%. Other combinations of L5 imbalance with activity bursts or trade flow also produced large timing differences.

These cell rates are descriptive and were searched after defining many combinations. They are useful for proposing interactions for a new-market test, not for estimating live probabilities from this sample.

Direct prediction of restricted waiting time in clock seconds did not generalize: test MAE was 6.49 seconds versus 5.75 for the median baseline. Restricted waiting time measured in number of trades did improve, with MAE 25.29 trades versus 40.24. This fits the classification result: the model recognizes order-flow and activity regimes, but conversion from event time to clock time is unstable.

## Interpretation

The strongest repeatable relationship is:

\[
P(\text{spread-clearing move within }h\mid
\text{book shape, trade flow, activity regime})
\]

Book variables carry most of the 1- and 5-second information. Temporal variables become more useful at 30 seconds. Flow and state history add smaller incremental timing information. Slower price structure alone is weak and unstable.

The missing component remains:

\[
P(\text{up}\mid\text{a move occurs},X_t).
\]

Without a stable directional probability, buying YES or NO before a predicted activity burst still pays the spread and fees without a demonstrated directional advantage. The current result may instead be useful for market-making controls, quote withdrawal, spread adjustment, execution scheduling, or selecting periods for a separate directional model.

## Scope and next locked experiment

This search uses 42,958 original Kalshi trade observations from one NFL and one MLB contract, producing 3,888 one-second test decisions. Per-second labels overlap, and only two independent markets are present. The block analysis reduces the false precision from overlapping labels but cannot replace testing on new contracts.

The next confirmatory specification is frozen by these results: use book + flow + temporal features for 1-second move probability, book + temporal for 5-second move probability, and no directional trade unless a separately trained direction model beats the baseline. Test those exact specifications on unseen Kalshi contracts before changing thresholds or feature families. A practical strategy test should use the timing score for quote cancellation or passive-order placement, with actual queue position and fill simulation.

## Files

- `conditional_search.py`: complete feature construction, first-passage labels, family search and locked selection
- `all_family_combinations.csv`: all classifier results
- `selected_test_results.csv`: validation-selected locked test results
- `selected_by_market.csv`: results separated by NFL and MLB
- `block_bootstrap.csv`: dependence-aware loss comparisons
- `conditional_bins.csv` and `pair_condition_tables.csv`: one- and two-variable conditioning tables
- `wait_time_family_combinations.csv` and `selected_wait_results.csv`: direct waiting-time tests
- `modeling_dataset.csv.gz`: derived one-second modeling data
- `feature_families.json`: exact classification of variables
