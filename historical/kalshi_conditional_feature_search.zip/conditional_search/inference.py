import json
import numpy as np,pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier

rng=np.random.default_rng(91);d=pd.read_csv('conditional_search/modeling_dataset.csv.gz');fam=json.load(open('conditional_search/feature_families.json'));sel=pd.read_csv('conditional_search/selected_test_results.csv');out=[]
for _,s in sel.iterrows():
 H=int(s.horizon); ycol=f'move_{H}s' if s.task=='move' else f'dir_{H}s';ok=d[ycol].notna();tr=(d.part=='train')&ok&(d.clock<=d.cut60-H);te=(d.part=='test')&ok;cols=sum((fam[k] for k in s.families.split('+')),[])
 if s.model=='linear':m=make_pipeline(SimpleImputer(),StandardScaler(),LogisticRegression(C=.1,max_iter=1000))
 else:m=make_pipeline(SimpleImputer(),HistGradientBoostingClassifier(max_depth=3,max_iter=100,learning_rate=.05,l2_regularization=2,min_samples_leaf=30,random_state=19))
 m.fit(d.loc[tr,cols],d.loc[tr,ycol].astype(int));y=d.loc[te,ycol].astype(int).to_numpy();p=np.clip(m.predict_proba(d.loc[te,cols])[:,1],1e-12,1-1e-12);q=np.repeat(d.loc[tr,ycol].mean(),len(y));q=np.clip(q,1e-12,1-1e-12)
 # Negative means the model improves log loss. Resample 60-second blocks within market.
 delta=-(y*np.log(p)+(1-y)*np.log(1-p))+(y*np.log(q)+(1-y)*np.log(1-q));z=d.loc[te,['market','clock']].copy();z['block']=(z.clock//60).astype(int);z['delta']=delta;blocks=[g.delta.to_numpy() for _,g in z.groupby(['market','block'])]
 boot=[]
 for _ in range(5000):
  take=[blocks[j] for j in rng.integers(0,len(blocks),len(blocks))];boot.append(np.concatenate(take).mean())
 out.append(dict(horizon=H,task=s.task,families=s.families,model_minus_baseline_logloss=delta.mean(),ci95_low=np.quantile(boot,.025),ci95_high=np.quantile(boot,.975),blocks=len(blocks)))
pd.DataFrame(out).to_csv('conditional_search/block_bootstrap.csv',index=False)
print(pd.DataFrame(out).to_string(index=False))
