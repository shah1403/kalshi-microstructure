import numpy as np,pandas as pd
from pathlib import Path
from scipy.optimize import minimize, minimize_scalar
from scipy.special import expit,logit
from sklearn.metrics import log_loss,brier_score_loss,roc_auc_score

P=Path('external_validation');d=pd.read_csv(P/'predictions.csv.gz');eps=1e-6;rows=[];outs=[]

def fit_intercept(p,y,prior=0.,ridge=.2):
 z=logit(np.clip(p,eps,1-eps))
 f=lambda a: -np.sum(y*np.log(expit(z+a)+1e-12)+(1-y)*np.log(1-expit(z+a)+1e-12))+ridge*(a-prior)**2
 return minimize_scalar(f,bounds=(-12,12),method='bounded').x

def fit_platt(p,y,ridge=2.):
 z=logit(np.clip(p,eps,1-eps))
 def f(v):
  q=expit(v[0]+v[1]*z)
  return -np.sum(y*np.log(q+1e-12)+(1-y)*np.log(1-q+1e-12))+ridge*(v[0]**2+(v[1]-1)**2)
 return minimize(f,[0,1],method='L-BFGS-B',bounds=[(-12,12),(-3,3)]).x

for (mk,H,task),g in d.groupby(['market','horizon','task']):
 g=g.sort_values('t').reset_index(drop=True);tt=g.t.to_numpy();y=g.y.to_numpy();raw=np.clip(g.p.to_numpy(),eps,1-eps)
 for window in [60,180,360]:
  pred={k:np.full(len(g),np.nan) for k in ['raw','rolling_rate','rolling_intercept','rolling_platt']}
  for i,t in enumerate(tt):
   # At t, the outcome of a forecast made at s is known only once s+H <= t.
   hist=np.flatnonzero((tt+H<=t)&(tt>=t-window))
   if len(hist)<30 or len(np.unique(y[hist]))<2:continue
   pred['raw'][i]=raw[i]
   rate=(y[hist].sum()+.5)/(len(hist)+1);pred['rolling_rate'][i]=rate
   a=fit_intercept(raw[hist],y[hist]);pred['rolling_intercept'][i]=expit(logit(raw[i])+a)
   a,b=fit_platt(raw[hist],y[hist]);pred['rolling_platt'][i]=expit(a+b*logit(raw[i]))
  common=np.logical_and.reduce([np.isfinite(v) for v in pred.values()])
  if common.sum()<30 or len(np.unique(y[common]))<2:continue
  for method,p in pred.items():
   yy=y[common];pp=np.clip(p[common],eps,1-eps)
   # Equal-width calibration error, reported only when a bin has observations.
   bid=np.minimum((pp*10).astype(int),9);ece=sum((bid==b).mean()*abs(pp[bid==b].mean()-yy[bid==b].mean()) for b in np.unique(bid))
   rows.append(dict(market=mk,horizon=H,task=task,window=window,method=method,n=len(yy),positives=int(yy.sum()),logloss=log_loss(yy,pp),brier=brier_score_loss(yy,pp),roc_auc=roc_auc_score(yy,pp),ece10=ece))
   for t0,y0,p0 in zip(tt[common],yy,pp):outs.append((mk,H,task,window,method,t0,y0,p0))

r=pd.DataFrame(rows);r.to_csv(P/'rolling_calibration_results.csv',index=False)
pd.DataFrame(outs,columns=['market','horizon','task','window','method','t','y','p']).to_csv(P/'rolling_calibration_predictions.csv.gz',index=False,compression='gzip')
# Macro-average across eligible market streams so a dense stream cannot dominate.
s=r.groupby(['horizon','task','window','method'],as_index=False).agg(markets=('market','nunique'),logloss=('logloss','mean'),brier=('brier','mean'),roc_auc=('roc_auc','mean'),ece10=('ece10','mean'))
s.to_csv(P/'rolling_calibration_summary.csv',index=False)
print(s.to_string(index=False))
