# External Kalshi sports validation

Completed September 21, 2026.

## Data found

The free public Kalshi order-book archive contained six previously unused game moneylines in a continuous July 19 capture:

| Class | Contract | Book updates retained |
|---|---|---:|
| MLB | Washington at Atlanta, WSH side | 15,015 |
| MLB | San Francisco at Seattle, SF side | 21,624 |
| MLB | Detroit at LA Angels, LAA side | 11,089 |
| MLB | Pittsburgh at Cleveland, CLE side | 6,930 |
| NBA Summer League | Golden State at LA Lakers, GSW side | 28,146 |
| NBA Summer League | Indiana at New Orleans, IND side | 2,957 |

Source: https://huggingface.co/datasets/lerchen3/kalshi-orderbook-alpha

The capture covers roughly eight minutes after combining four consecutive archive shards. It is a dense late-game or settlement-period window, not six complete games or six independent dates.

A separate regular-season NBA sample, Philadelphia at Toronto on January 11, was found here:

https://huggingface.co/datasets/Coyevans/polymarket-kalshi-scoresync-orderbook-sample

It has 1,844 top-of-book snapshots at approximately 33-second median cadence, no depth sizes and no trade tape. It cannot test the frozen 1-second and 5-second L2 model, so it was retained as source data but not mixed into the performance numbers.

CryptoStruct indexes many additional completed NFL and NCAA football contracts. Its free-sample endpoint did not provide another downloadable NFL or college-football recording. Kalshi's public API does not provide historical L2 reconstruction. Those indexed paid records were not represented as free data or silently replaced with candles.

## Test design

The exact first-passage target was retained: whether the midpoint moves farther than the current spread within 1, 5 or 30 seconds.

The public archive has full depth updates but no trades. Therefore the full book + flow + temporal model cannot be evaluated. A reduced frozen book model was used with L1/L5 imbalance, logged bid and ask depth, total depth, spread, depth skew and depletion. Its coefficients were trained on the earlier NFL and MLB data. No coefficient was refit on the new outcomes.

Because late-game movement base rates were radically different, the first 40% of each new market was used only to shift the probability intercept. The final 60% was scored, with horizon-crossing observations purged. The feature coefficients and ranking remained frozen.

## Result

The new data does **not confirm a stable, calibrated timing edge**.

Three markets entered a nearly continuous repricing or settlement regime in the scored period:

| Market | 1-second move rate in scored period |
|---|---:|
| PIT-CLE | 99.6% |
| SF-SEA | 99.6% |
| GSW-LAL Summer League | 99.6% |

In those markets, ranking statistics can appear excellent while conveying little useful information because almost every observation moves. Their earlier calibration periods had only 55% to 66% one-second move rates, so the main forecast problem became an abrupt regime change.

Washington-Atlanta was the only reasonably balanced MLB validation market:

| Horizon | Move rate | ROC AUC | Model log loss | Past-rate baseline |
|---|---:|---:|---:|---:|
| 1 second | 55.3% | 0.823 | 0.779 | 0.773 |
| 5 seconds | 56.9% | 0.351 | 0.801 | 0.746 |
| 30 seconds | 66.4% | 0.823 | 0.692 | 0.687 |

The model ranked 1-second and 30-second observations reasonably in that market, but its probabilities were slightly worse than the simple past-rate baseline. At 5 seconds it failed both ranking and probability accuracy.

Detroit-LAA and Indiana-New Orleans had too few moves or too little class variation in the short window for a calibrated holdout score. Raw AUC values based on one to three positive events are not treated as evidence.

Direction failed again. Late settlement windows were strongly one-sided, several directional tests had only two to five up moves, and the frozen model usually had worse log loss than the past-only direction rate. There is no validated YES/NO trading signal.

## Updated conclusion

The earlier two-market result showed that book and activity features could predict near-term movement within those recordings. The new markets show that the probability relationship is not stable across sports contracts and game regimes. A high movement-ranking score can also be misleading when the market enters a state where almost every second contains a spread-clearing change.

The defensible statement is now:

1. Book state contains some information about the relative ordering of near-term movement risk.
2. The mapping from that state to an absolute movement probability changes sharply across contracts and late-game regimes.
3. Exact seconds-to-move, direction and executable directional profit remain unvalidated.
4. A usable system needs explicit regime detection and should be tested on complete games from multiple independent dates.

## Files

- `external_validation.py`: extraction, frozen transfer and past-only calibration
- `external_books_1s.csv.gz`: derived one-second books and targets
- `raw_transfer_results.csv`: uncalibrated frozen transfer
- `calibrated_results.csv`: chronological calibrated holdout results
- `predictions.csv.gz`: observation-level predictions
- `source_counts.json`: retained update counts
- `nba_phi_tor.csv`: separate regular-season NBA top-of-book sample

