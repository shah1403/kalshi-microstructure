# Rolling live recalibration experiment

The frozen book model was recalibrated sequentially on each untouched market. At time `t`, it used only outcomes from predictions whose horizon had already elapsed. This prevents a five-second prediction from using the still-unknown result of a forecast made two seconds earlier.

Four methods were compared:

- raw frozen probability
- rolling empirical movement rate
- rolling intercept adjustment
- rolling slope plus intercept adjustment (Platt scaling)

Windows of 60, 180 and 360 seconds were tested and all results are reported. The 60-second intercept method is the clearest short-horizon result.

| Move target | Raw log loss | Rolling-intercept log loss | Raw AUC | Rolling AUC | Raw ECE | Rolling ECE |
|---|---:|---:|---:|---:|---:|---:|
| Within 1 second | 1.382 | 0.492 | 0.918 | 0.907 | 0.478 | 0.172 |
| Within 5 seconds | 0.803 | 0.532 | 0.863 | 0.852 | 0.329 | 0.188 |
| Within 30 seconds | 0.618 | 0.651 | 0.907 | 0.623 | 0.260 | 0.232 |

Metrics are macro-averaged over eligible market streams so one dense contract cannot dominate. Lower log loss, Brier score and ECE are better; higher AUC is better.

The result supports the correction proposed after the first external test. The book model retained useful short-horizon ranking information, while its absolute probability level changed by market regime. Updating only the log-odds intercept adapts that level without relearning the feature relationships:

\[
\tilde p_t=\sigma(\operatorname{logit}(\hat p_t)+a_t).
\]

At one and five seconds this greatly improved probability accuracy and preserved nearly all AUC. Learning both an intercept and slope from the short rolling window added estimation noise and did not improve the aggregate result.

At 30 seconds, raw probabilities were already stronger and rolling recalibration slightly worsened log loss. The 30-second labels overlap heavily and mature slowly, leaving fewer independent observations inside a 60-second window. A longer window did not produce a consistent improvement either.

Direction probabilities improved numerically after rolling calibration because the markets became strongly one-sided near settlement. However, a rolling direction base rate was generally competitive with or better than feature-based calibration, and directional ranking remained unstable. This is adaptation to recent directional frequency, not evidence that the book predicts direction.

The updated conclusion is:

1. The short-horizon movement-ranking signal survived.
2. Most of the external failure at one and five seconds was probability-level miscalibration.
3. A simple rolling log-odds intercept is preferable to refitting the whole model in a short window.
4. Thirty-second movement probability and direction remain unresolved.
5. This window is short and late-game. Complete unseen games are still required before using the probabilities for sizing or execution.

Files:

- `rolling_calibration.py`: leakage-safe sequential implementation
- `rolling_calibration_results.csv`: every market, horizon, window and method
- `rolling_calibration_summary.csv`: macro averages
- `rolling_calibration_predictions.csv.gz`: observation-level calibrated predictions

