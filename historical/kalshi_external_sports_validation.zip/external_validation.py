import gzip,json
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,roc_auc_score,average_precision_score
from scipy.optimize import minimize_scalar
from scipy.special import expit,logit

OUT=Path('external_validation');OUT.mkdir(exist_ok=True)
TICKERS={
 'MLB_WSH_ATL':'KXMLBGAME-26JUL182205WSHATH-WSH',
 'MLB_SF_SEA':'KXMLBGAME-26JUL182008SFSEA-SF',
 'MLB_DET_LAA':'KXMLBGAME-26JUL182207DETLAA-LAA',
 'MLB_PIT_CLE':'KXMLBGAME-26JUL181610PITCLE-CLE',
 'NBA_SUMMER_GSW_LAL':'KXNBASUMMERGAME-26JUL18GSWLAL-GSW',
 'NBA_SUMMER_IND_NOP':'KXNBASUMMERGAME-26JUL18INDNOP-IND',
}
rev={v:k for k,v in TICKERS.items()};events={k:[] for k in TICKERS}
sources=['hf-kalshi-orderbooks.jsonl.gz']+[f'external_validation/shards/shard{i}.jsonl.gz' for i in range(1,4)]
for source in sources:
 with gzip.open(source,'rt') as f:
  for line in f:
   x=json.loads(line);ticker=x.get('ticker')
   if ticker not in rev or x.get('record_type') not in ('snapshot','delta'):continue
   b=x.get('book',{}).get('yes',{}); bids=b.get('bid_levels') or [];asks=b.get('ask_levels') or []
   if not bids or not asks:continue
   events[rev[ticker]].append((x['received_ts_ns']/1e9,bids,asks))
for k in events:events[k].sort(key=lambda z:z[0])

def make(name,ev):
 # Deduplicate and sample once per second, using only the last published book.
 ts=np.array([z[0] for z in ev]);start=np.ceil(ts.min());end=np.floor(ts.max());sec=np.arange(start,end-30)
 ix=np.searchsorted(ts,sec,side='right')-1;rows=[]
 for q,j in zip(sec,ix):
  bids,asks=ev[j][1],ev[j][2];bp,bq=bids[0];ap,aq=asks[0];b5=sum(v for _,v in bids[:5]);a5=sum(v for _,v in asks[:5])
  rows.append((q,(bp+ap)/200,(ap-bp)/100,bq,aq,(bq-aq)/(bq+aq+1e-9),(b5-a5)/(b5+a5+1e-9),np.log1p(bq),np.log1p(aq),np.log1p(bq+aq),(bq-aq)/(bq+aq+1e-9)))
 d=pd.DataFrame(rows,columns=['t','mid','spread','bq','aq','imb1','imb5','log_bq','log_aq','depth','depth_skew']);d['depletion_scaled']=(d.bq+d.aq).diff().fillna(0)/(d.bq+d.aq+1)
 for H in [1,5,30]:
  y=[];di=[]
  m=d.mid.to_numpy();s=d.spread.to_numpy()
  for i in range(len(d)):
   future=m[i+1:min(i+H+1,len(d))];hit=np.flatnonzero(np.abs(future-m[i])>s[i]+1e-9)
   if len(hit): y.append(1);di.append(int(future[hit[0]]>m[i]))
   else:y.append(0);di.append(np.nan)
  d[f'move_{H}s']=y;d[f'dir_{H}s']=di
 d['market']=name;return d

new=pd.concat([make(k,v) for k,v in events.items() if len(v)>20],ignore_index=True);new.to_csv(OUT/'external_books_1s.csv.gz',index=False,compression='gzip')
old=pd.read_csv('conditional_search/modeling_dataset.csv.gz');cols=['imb1','imb5','log_bq','log_aq','depth','spread','depth_skew','depletion_scaled'];rows=[];pred=[]
for H in [1,5,30]:
 for task in ['move','direction']:
  yc=f'move_{H}s' if task=='move' else f'dir_{H}s';tr=old[yc].notna();model=make_pipeline(SimpleImputer(),StandardScaler(),LogisticRegression(C=.1,max_iter=1000));model.fit(old.loc[tr,cols],old.loc[tr,yc].astype(int));base=old.loc[tr,yc].mean()
  for mk,g in new.groupby('market'):
   ok=g[yc].notna();y=g.loc[ok,yc].astype(int).to_numpy()
   if len(y)<20 or len(np.unique(y))<2:continue
   p=model.predict_proba(g.loc[ok,cols])[:,1];q=np.repeat(base,len(y));rows.append(dict(market=mk,horizon=H,task=task,n=len(y),positives=int(y.sum()),rate=y.mean(),logloss=log_loss(y,p),baseline_logloss=log_loss(y,q),roc_auc=roc_auc_score(y,p),average_precision=average_precision_score(y,p)))
   for t,yy,pp in zip(g.loc[ok,'t'],y,p):pred.append((mk,H,task,t,yy,pp))
pd.DataFrame(rows).to_csv(OUT/'raw_transfer_results.csv',index=False);pred=pd.DataFrame(pred,columns=['market','horizon','task','t','y','p']);pred.to_csv(OUT/'predictions.csv.gz',index=False,compression='gzip')
# Past-only intercept calibration: first 40% of each new market calibrates the
# frozen score; the final 60% is evaluated. Purge H seconds at the boundary.
cal=[]
for (mk,H,task),g in pred.groupby(['market','horizon','task']):
 g=g.sort_values('t');cut=g.t.quantile(.4);a=g[g.t<=cut-H];b=g[g.t>cut]
 if len(a)<20 or len(b)<20 or a.y.nunique()<2 or b.y.nunique()<2:continue
 lp=logit(np.clip(a.p.to_numpy(),1e-8,1-1e-8));y=a.y.to_numpy();fun=lambda c: -np.mean(y*np.log(expit(lp+c)+1e-12)+(1-y)*np.log(1-expit(lp+c)+1e-12));shift=minimize_scalar(fun,bounds=(-15,15),method='bounded').x
 yy=b.y.to_numpy();pp=expit(logit(np.clip(b.p.to_numpy(),1e-8,1-1e-8))+shift);base=np.repeat(a.y.mean(),len(yy))
 cal.append(dict(market=mk,horizon=H,task=task,n=len(yy),positives=int(yy.sum()),calibration_rate=a.y.mean(),test_rate=yy.mean(),logloss=log_loss(yy,pp),past_rate_baseline_logloss=log_loss(yy,base),roc_auc=roc_auc_score(yy,pp),average_precision=average_precision_score(yy,pp)))
pd.DataFrame(cal).to_csv(OUT/'calibrated_results.csv',index=False)
json.dump({k:len(v) for k,v in events.items()},open(OUT/'source_counts.json','w'),indent=2)
print(pd.DataFrame(cal).to_string(index=False))
