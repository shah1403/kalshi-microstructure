from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path("kalshi_next_move_strategy")
OUT.mkdir(exist_ok=True)

DATASETS = {
    "BTC15M": "quant_results/kalshi-btc15m-2026-09-11.txt.zst.features.csv.gz",
    "NFL": "sports_v4/NFL/features.csv.gz",
    "MLB": "sports_v4/MLB/features.csv.gz",
}


def kalshi_fee(price, q):
    return math.ceil(100 * 0.07 * q * price * (1 - price) - 1e-10) / 100


def max_contracts(price, cash):
    best = 0
    for q in range(1, 1000):
        if q * price + kalshi_fee(price, q) <= cash + 1e-12:
            best = q
        else:
            break
    return best


def entry_exit_prices(row_entry, row_exit, side):
    if side == 1:
        return float(row_entry.ask), float(row_exit.bid)
    return 1.0 - float(row_entry.bid), 1.0 - float(row_exit.ask)


def meaningful_events(d):
    ev = []
    for seg, g in d.groupby("segment", sort=False):
        idx = g.index.to_numpy()
        mid = g.mid.to_numpy()
        spread = g.spread.to_numpy()
        valid = (spread > 0) & (g.bid.to_numpy() > 0) & (g.ask.to_numpy() < 1)
        anchor = 0
        for k in range(1, len(g)):
            if not valid[k] or not valid[anchor]:
                anchor = k
                continue
            if abs(mid[k] - mid[anchor]) > spread[anchor] + 1e-12:
                ev.append(dict(segment=int(seg), event_i=int(idx[k]), anchor_i=int(idx[anchor]), up=int(mid[k] > mid[anchor]), move_size=float(abs(mid[k] - mid[anchor])), wait_events=int(k - anchor), wait_seconds=float(g.t.iloc[k] - g.t.iloc[anchor])))
                anchor = k
    return pd.DataFrame(ev)


def predict(d, events):
    rows = []
    for seg, evs in events.groupby("segment", sort=False):
        past = []
        for _, e in evs.iterrows():
            j = int(e.anchor_i)
            last = past[-1]["up"] if past else -1
            prior = (sum(x["up"] for x in past) + 1) / (len(past) + 2)
            if last >= 0:
                nxt = [past[k + 1]["up"] for k in range(len(past) - 1) if past[k]["up"] == last]
                p_hist = (sum(nxt) + 20 * prior) / (len(nxt) + 20)
            else:
                p_hist = prior
            b = int(np.clip((float(d.imb1.iloc[j]) + 1) * 5, 0, 9))
            bucket = [x for x in past if x["bin"] == b]
            p_imb = (sum(x["up"] for x in bucket) + 20 * prior) / (len(bucket) + 20)
            both = [x for x in past if x["bin"] == b and x["last"] == last]
            p_comb = (sum(x["up"] for x in both) + 20 * p_hist) / (len(both) + 20)
            rows.append(dict(segment=int(seg), anchor_i=j, event_i=int(e.event_i), up=int(e.up), wait_events=int(e.wait_events), wait_seconds=float(e.wait_seconds), move_size=float(e.move_size), bin=b, last=last, p_rate=prior, p_history=p_hist, p_imbalance=p_imb, p_combined=p_comb))
            past.append(dict(up=int(e.up), bin=b, last=last))
    return pd.DataFrame(rows)


def split_part(pos, n):
    if pos < 0.6 * n:
        return "train"
    if pos < 0.8 * n:
        return "val"
    return "test"


def eval_direction(pred):
    out = []
    for market, mdf in pred.groupby("market"):
        for model in ["rate", "history", "imbalance", "combined"]:
            for part, g in mdf.groupby("part"):
                if g.empty:
                    continue
                correct = ((g["p_" + model] >= .5) == (g.up == 1))
                out.append(dict(market=market, part=part, model=model, events=len(g), DA=float(correct.mean()), up_rate=float((g.up == 1).mean()), avg_wait_events=float(g.wait_events.mean()), avg_wait_seconds=float(g.wait_seconds.mean()), avg_move=float(g.move_size.mean())))
    return pd.DataFrame(out)


def run_trades(datasets, pred):
    trades = []
    thresholds = [.50, .525, .55, .575, .60, .625, .65, .675, .70, .75, .80]
    for market, pmarket in pred.groupby("market"):
        d = datasets[market]
        val = pmarket[pmarket.part == "val"].sort_values("anchor_i")
        test = pmarket[pmarket.part == "test"].sort_values("anchor_i")
        for model in ["rate", "history", "imbalance", "combined"]:
            best_c, best_net = .5, -1e18
            for c in thresholds:
                cash = 5.0
                for _, r in val.iterrows():
                    prob = float(r["p_" + model])
                    side = 1 if prob >= c else (-1 if prob <= 1 - c else 0)
                    if side == 0:
                        continue
                    entry, exitp = entry_exit_prices(d.iloc[int(r.anchor_i)], d.iloc[int(r.event_i)], side)
                    q = max_contracts(entry, cash)
                    if q <= 0:
                        continue
                    net = q * (exitp - entry) - kalshi_fee(entry, q) - kalshi_fee(exitp, q)
                    cash += net
                if cash - 5 > best_net:
                    best_net, best_c = cash - 5, c
            for c in sorted(set([.5, .55, .6, .65, .7, .75, .8, best_c])):
                label = "val_selected" if c == best_c else f"c{c:.3f}"
                cash = 5.0
                busy_until = -1
                for _, r in test.iterrows():
                    j, x = int(r.anchor_i), int(r.event_i)
                    if j <= busy_until:
                        continue
                    prob = float(r["p_" + model])
                    side = 1 if prob >= c else (-1 if prob <= 1 - c else 0)
                    if side == 0:
                        continue
                    entry, exitp = entry_exit_prices(d.iloc[j], d.iloc[x], side)
                    q = max_contracts(entry, cash)
                    if q <= 0:
                        continue
                    fees = kalshi_fee(entry, q) + kalshi_fee(exitp, q)
                    gross = q * (exitp - entry)
                    net = gross - fees
                    before = cash
                    cash += net
                    correct = bool((r.up == 1 and side == 1) or (r.up == 0 and side == -1))
                    trades.append(dict(market=market, model=model, threshold=c, threshold_label=label, anchor_i=j, exit_i=x, side="YES" if side == 1 else "NO", p=prob, q=q, entry=entry, exit=exitp, gross=gross, fees=fees, net=net, cash_before=before, cash_after=cash, actual_up=int(r.up), correct=correct, wait_events=int(r.wait_events), wait_seconds=float(r.wait_seconds)))
                    busy_until = x
    return pd.DataFrame(trades)


def summarize(trades):
    rows = []
    if trades.empty:
        return pd.DataFrame()
    for key, g in trades.groupby(["market", "model", "threshold_label", "threshold"]):
        market, model, label, c = key
        pnl = g.net.to_numpy()
        eq = np.r_[5.0, 5.0 + np.cumsum(pnl)]
        dd = np.maximum.accumulate(eq) - eq
        rows.append(dict(market=market, model=model, threshold_label=label, threshold=c, trades=len(g), contracts=int(g.q.sum()), DA=float(g.correct.mean()), avg_wait_events=float(g.wait_events.mean()), avg_wait_seconds=float(g.wait_seconds.mean()), gross=float(g.gross.sum()), fees=float(g.fees.sum()), net=float(pnl.sum()), ending_cash=float(eq[-1]), max_drawdown=float(dd.max())))
    return pd.DataFrame(rows).sort_values(["market", "model", "threshold"])


def plots(datasets, trades):
    for market in ["BTC15M", "NFL", "MLB"]:
        for model in ["combined", "imbalance", "history"]:
            g = trades[(trades.market == market) & (trades.model == model) & (trades.threshold_label == "val_selected")].copy()
            if g.empty:
                continue
            d = datasets[market]
            start = int(g.anchor_i.min())
            end = min(len(d), int(g.exit_i.max()) + 100)
            dd = d.iloc[start:end]
            fig, axes = plt.subplots(2, 1, figsize=(14, 7), layout="constrained", sharex=True)
            axes[0].plot(dd.index - start, dd.mid * 100, color="#30394b", lw=.9)
            colors = np.where(g.correct, "#128558", "#cc354b")
            axes[0].scatter(g.anchor_i - start, d.mid.iloc[g.anchor_i].to_numpy() * 100, c=colors, s=24, zorder=3)
            axes[0].set_title(f"{market} next-move Kalshi strategy: {model}, validation-selected threshold")
            axes[0].set_ylabel("YES midpoint (cents)")
            axes[0].grid(alpha=.15)
            axes[1].plot(g.anchor_i - start, g.cash_after, color="#30394b", lw=1.2)
            axes[1].axhline(5, color="#777", alpha=.5)
            axes[1].set_xlabel("Feature rows into test segment")
            axes[1].set_ylabel("cash ($)")
            axes[1].grid(alpha=.15)
            fig.savefig(OUT / f"{market.lower()}_next_move_{model}.png", dpi=160)
            plt.close(fig)


def main():
    datasets = {}
    audits = []
    preds = []
    for market, path in DATASETS.items():
        d = pd.read_csv(path).sort_values("t").reset_index(drop=True)
        datasets[market] = d
        ev = meaningful_events(d)
        p = predict(d, ev)
        if p.empty:
            continue
        p["market"] = market
        p["event_pos"] = np.arange(len(p))
        p["part"] = [split_part(x, len(p)) for x in p.event_pos]
        preds.append(p)
        audits.append(dict(market=market, rows=len(d), meaningful_events=len(ev), test_events=int((p.part == "test").sum()), avg_wait_events=float(ev.wait_events.mean()) if len(ev) else np.nan, median_wait_events=float(ev.wait_events.median()) if len(ev) else np.nan, avg_wait_seconds=float(ev.wait_seconds.mean()) if len(ev) else np.nan, avg_move=float(ev.move_size.mean()) if len(ev) else np.nan))
    pred = pd.concat(preds, ignore_index=True)
    direction = eval_direction(pred)
    trades = run_trades(datasets, pred)
    summary = summarize(trades)
    plots(datasets, trades)
    pd.DataFrame(audits).to_csv(OUT / "audit.csv", index=False)
    pred.to_csv(OUT / "next_move_predictions.csv", index=False)
    direction.to_csv(OUT / "direction_metrics.csv", index=False)
    trades.to_csv(OUT / "trades.csv", index=False)
    summary.to_csv(OUT / "trade_summary.csv", index=False)
    print("AUDIT")
    print(pd.DataFrame(audits).to_string(index=False))
    print("\nDIRECTION TEST")
    print(direction[direction.part == "test"].to_string(index=False))
    print("\nVAL SELECTED TRADE SUMMARY")
    print(summary[summary.threshold_label == "val_selected"].to_string(index=False))


if __name__ == "__main__":
    main()
