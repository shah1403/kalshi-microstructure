# Recovered 10-market Kalshi replay

The interrupted recording was recovered and replayed successfully. The usable
window was **7:25:05–7:33:50 a.m. Eastern on September 29, 2026**, approximately
8 minutes 46 seconds, not the intended 30 minutes. This is a paper-only replay.
No real orders were sent.

## Portfolio result

| Leg | Funded paper trades | Gross | Fees | Net |
|---|---:|---:|---:|---:|
| Maker | 0 | $0 | $0 | $0 |
| Taker | 0 | $0 | $0 | $0 |
| Same-contract arbitrage | 0 | $0 | $0 | $0 |

Cash stayed at $100; observed drawdown was $0. No funded positions remained open.
No model reached initialization, so this is **not evidence of successful model
abstention, profitability, safety, or predictive accuracy**.

## Why no trades were taken

Maker initialization requires 30 completed hypothetical quote outcomes **per
market**. The largest market sample was 17. The separate flow model requires
100 matured windows; the largest sample was 36. Taker initialization requires
30 matured qualifying anchors; across this capture there were only seven anchors
and one fully matured outcome. The remaining six were censored at the recording
cutoff. Even 457 total trades across markets do not imply 30 qualifying anchors
in any one market.

| Market | Trades | Matured maker observations | Matured taker anchors |
|---|---:|---:|---:|
| Hubert Hurkacz | 135 | 17 | 1 |
| Daniil Medvedev | 41 | 0 | 0 |
| Flavio Cobolli | 0 | 0 | 0 |
| ILLYRIANS (CS2) | 6 | 0 | 0 |
| ENJOY (CS2) | 12 | 1 | 0 |
| eternal premium (CS2) | 22 | 0 | 0 |
| STATE (CS2) | 228 | 7 | 0 |
| San Diego | 5 | 0 | 0 |
| Chicago WS | 7 | 0 | 0 |
| New York G | 1 | 0 | 0 |

Ticker mappings and full market metadata are included in `capture_summary.json`.
The same-market distributions start empty. No other market's outcomes, historical
test results or future observations were used to bypass initialization.

## Hypothetical maker fill observations

The replay also followed overlapping, unfunded one-contract quotes to initialize
the rolling distribution. These are simulated public-feed fills, not exchange
own-order fills or actual portfolio trades.

| Market | Completed quote observations | Fully paired | Any fill |
|---|---:|---:|---:|
| Hubert Hurkacz | 17 | 8 | 15 |
| ENJOY | 1 | 0 | 1 |
| STATE | 7 | 1 | 7 |
| Total | 25 | 9 | 23 |

Thus 9 completed a full pair, 14 had some fill without completing the full pair,
and 2 had no fill. This is **36% fully paired among these completed observations**,
not model prediction accuracy or an unbiased estimate across all issued quotes.
End-of-recording and data-pause censoring matter. The outcomes overlap and should
not be summed into an investable strategy PnL.

One-tick compression was possible at 23 eligible decision points: 8 in Hurkacz,
2 in ENJOY and 13 in STATE. At the other eligible points, the book was already
one tick wide. Improving an existing wider spread removes visible queue ahead
at new price levels but still does not ensure both sides trade before the market
moves. These observed outcomes illustrate the distinction.

The hypothetical completed episodes had aggregate net returns of -$0.2885 for
Hurkacz, -$0.1078 for ENJOY and -$1.4562 for STATE. These overlapping initialization
probes were never funded by the portfolio and are **not the strategy's PnL**.
The strategy never produced a ready maker forecast in this sample.

## Arbitrage and accuracy

The seeker checked 71,945 valid book snapshots/updates and found no same-contract
YES+NO pair below $1 after depth, both taker fees and slippage. This count is not
71,945 independent opportunities. Cross-market baskets are outside this test.

Directional accuracy, maker prediction accuracy and flow-model accuracy are
unavailable because the corresponding models did not initialize. It would be
incorrect to report zero-trade results as 100% accuracy or zero prediction error.

## Recovery and fidelity

- Recovered 72,809 complete JSONL records: 71,935 book deltas, 457 public trades,
  ten snapshots, 397 lifecycle messages, three subscription acknowledgments,
  six timers and one metadata header. There were no leftover partial JSON bytes.
- The gzip footer was missing. The original recording was preserved unchanged;
  a separate, properly closed recovered gzip contains only the existing complete
  records. Its source SHA-256 is recorded in the recovery manifest.
- Replay passed sequence-continuity checks. No fake messages, end-of-session
  actions, forced mid-price liquidations, or completed tail outcomes were added.
- The original 1,800-second planned duration was retained. The strategy was not
  told in hindsight to stop before the observed crash at 525.63 seconds.
- Six unfinished taker labels were explicitly censored. Pending maker observations
  were not learned as completed outcomes. One censored taker label had already
  observed an UP crossing, but its required full exposure had not matured.
- End-of-session fee metadata was unavailable. This is explicitly an incomplete,
  start-fee-schedule replay, not a claim that end fees were verified. Captured maker
  multipliers were 1 for tennis/NFL, 0 for CS2 and 0.5 for MLB; taker multipliers
  were 1 except MLB at 0.5. No actual fees were incurred because no trades executed.
- Median incoming trade timestamp lag was 16.96ms; p95 22.88ms. The existing 5ms
  modeled action latency remains additional to incoming feed lag.
- All original strategy thresholds remain unchanged. Public-book fill modeling,
  hidden queue, reaction to hypothetical tighter quotes, impact and asynchronous
  channel ordering remain limitations.
- Ten shared-engine tests and two new interrupted-file recovery tests passed.
  The new tests check unchanged original bytes, preserved duration, discarded
  incomplete final JSON, explicit incomplete-run acknowledgment and missing final
  fee metadata disclosure. These are targeted checks, not a claim of no bugs.

## Reproduce

From the bundle root:

```bash
python -m unittest discover -s combined_paper -p 'test_recovery.py' -v
python combined_paper/replay_combined.py combined_paper/ten_market_20260929T1122Z_recovered --allow-incomplete
```

The included recorder and replay source contain no supplied credentials. No
authenticated API access is required to replay the saved data.
