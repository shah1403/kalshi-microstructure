"""Read one credential JSON line from stdin, capture, then replay; never send orders."""
import argparse
import asyncio
import json
import os
from pathlib import Path
import time
from record_live import record
from replay_combined import run

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--seconds', type=int, default=1800)
    parser.add_argument('tickers', nargs='+')
    args = parser.parse_args()
    if not 1 <= args.seconds <= 1800:
        parser.error('Bounded capture must be 1 to 1800 seconds')
    credentials = json.loads(input())
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=False)
    status = {'pid': os.getpid(), 'started_wall': time.time(), 'duration_seconds': args.seconds,
              'tickers': args.tickers, 'mode': 'data capture followed by paper replay',
              'real_orders': False, 'state': 'starting_capture'}
    def save():
        (out / 'run_status.json').write_text(json.dumps(status, indent=2))
        print(json.dumps(status), flush=True)
    save()
    try:
        asyncio.run(record(args, credentials))
        credentials.clear()
        status['state'] = 'replaying'
        save()
        run(out)
        status['state'] = 'completed'
        status['completed_wall'] = time.time()
        save()
    except Exception as exc:
        credentials.clear()
        status['state'] = 'failed'
        status['error_type'] = type(exc).__name__
        save()
        raise
