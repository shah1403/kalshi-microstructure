# Authenticated Kalshi three-leg paper pilot

## What actually ran

The user-supplied credentials successfully authenticated a Kalshi market-data
WebSocket. Five markets were recorded for a bounded five-minute window on
2026-09-28 UTC. No exchange order, cancellation, balance, or position endpoint
was called. The session is now stopped; nothing is running unattended.

The new capture was then replayed causally through the combined paper simulator.
The forecasts and paper order decisions were generated during replay, not sent
to the exchange during capture. This distinction matters: it is not a live
own-fill validation or a deployed continuous service.

## Result

| Component | Paper trades | Gross PnL | Fees | Net PnL |
|---|---:|---:|---:|---:|
| Maker | 0 | $0 | $0 | $0 |
| Taker | 0 | $0 | $0 | $0 |
| Same-contract paired arbitrage | 0 | $0 | $0 | $0 |

Shared paper cash stayed at **$100**, with **$0 observed drawdown** and no open
positions. This is a connectivity/initialization pilot, NOT evidence of safety,
profitability or a failed strategy. Zero-trade drawdown is uninformative.

## Markets and activity

| Market ticker | Selection role | Recorded trade messages |
|---|---|---:|
| KXMLBGAME-26SEP292200CHCSD-SD | San Diego vs Chicago C, near-even maker candidate | 6 |
| KXMLBGAME-26SEP291700CWSHOU-CWS | Chicago WS vs Houston, near-even maker candidate | 7 |
| KXATPMATCH-26SEP28SAFCOB-COB | Flavio Cobolli, near-even maker candidate | 5 |
| KXMLBGAME-26SEP302200CHCSD-SD | Next San Diego/Chicago C game, wider-spread candidate | 0 |
| KXNFLGAME-26SEP28PHICHI-PHI | Busy Philadelphia/Chicago NFL flow/taker diagnostic; outside maker band | 1,446 |

Selection checked open-market metadata, odds, spread, volume and recent trades.
Daily volume did not imply short-window trading activity. These are three sports
series, not five independent asset classes. The two San Diego contracts are
different dates. The sample does not establish that no other good market existed.

Capture totals: 1,464 trade messages, 2,003 book deltas, five initial snapshots,
and 110 lifecycle messages. All observed sequence continuity checks passed.

## Why there were no trades

### Maker

Only 18 total trade messages arrived across the four near-even candidates. None
reached the 30 fully matured quote-outcome initialization threshold. Therefore
there were **zero ready maker probability forecasts**, not ready forecasts which
successfully rejected losing opportunities.

At the five eligible trade-stride decisions the spread was already one tick.
There were no observed inside-spread compression opportunities at those decision
points. The wider-spread candidate produced no trades at all. Joining a one-tick
book puts existing displayed orders ahead; it does not earn new-price priority.

Quiet feeds also caused conservative ten-second strategy book-age pauses. Labels
and hypothetical queues spanning pauses were censored. The continuous raw feed
was retained; strategy resumption used a full contemporaneous reconstruction on
the next book update. Quiet is not proof of missing feed data, but this pilot kept
the prior conservative staleness control rather than pretending uninterrupted fills.

### Taker

The NFL market produced **251 completed first-passage labels, all ZERO**: neither
side reached the reference one-contract executable profit barrier, including
taker fees and slippage, within its 50-trade observation window.

There were **211 initialized forecasts**, all abstentions. Their predicted ZERO
probability ranged from **95.12% to 99.57%**. Neither directional probability
crossed the 45% exception threshold. No directional accuracy can be reported,
because there were no chosen directions and no nonzero reference outcomes.

This supports only the narrow observation that the locked no-crossing rule was
respected in this window. It does not validate the model on moving markets.

### Arbitrage seeker

Across **2,008 valid book checks**, there was no same-contract YES+NO acquisition
pair costing less than $1 after executable depth, both taker fees and slippage.
Each check is a book update, not an independent opportunity.

In a consistent uncrossed binary book, YES ask + NO ask = $1 + YES spread. Thus
the requested same-contract pair cannot be below $1 in that representation.
The scanner refuses crossed/stale-book pseudo-arbitrage. Cross-market baskets
were not searched. The historical two-leg latency/failure simulator still passes
its synthetic tests, but no actual candidate exercised it in this capture.

## Flow forecasts, diagnostic only

NFL produced 169 scored forecasts after the original 100-window flow warmup:

| Forecast | Unconditional rolling distribution | Fully conditioned distribution |
|---|---:|---:|
| Next taker side | 95.86% | 95.86% |
| Opposite-side trade within five trades | 85.21% | 86.39% |

High next-side accuracy did not show an improvement over the baseline. The timing
difference amounts to only two extra correct classifications and is not robust
evidence from this short, overlapping sample. These are taker-flow predictions,
not order-fill accuracy or trade profitability.

## Fees, latency, implementation and tests

- Resolved live series/event metadata gave a **0.5 fee multiplier for the selected
  MLB markets**, and **1 for the selected NFL and ATP markets**. Start/end resolved
  fee metadata agreed. This corrects the earlier blanket multiplier-1 illustration
  for the currently selected MLB contracts, not all historical MLB fees.
- At prices near 50c, a completed 1c maker capture with multiplier 0.5 leaves
  approximately 0.56c per one-contract pair after centicent rounding. At multiplier
  1, approximately 0.12c remains. These are hypothetical fully paired margins,
  NOT measured pilot earnings. Partial fills, one-sided exits and price moves can
  overwhelm those margins.
- Median observed incoming trade timestamp lag was **14.97 ms**, 95th percentile
  **18.13 ms**, plus **5 ms modeled action latency**. The simulator does not claim
  5 ms end-to-end execution. Cross-channel ordering remains uncertain.
- One shared wallet, maximum one funded leg at a time; taker probability sizing
  and 45% exception preserved. Maker quote size fixed at one contract for this
  signal/queue pilot. No shadow quote PnL enters the cash ledger.
- Maker quoting was changed explicitly to a one-tick spread, unlike the earlier
  v2 spread/skew experiment. New inside-spread prices have zero visible queue;
  existing prices retain displayed queue ahead. The pilot uses flow-based cancel
  and exit controls, but not dynamic quote skew/replacement.
- Maker gate set before observing PnL: at least 30 completed labels, positive
  expected net, positive pair margin, and predicted pair fill >=98% OR conditional
  one-sided loss <=$0.005. These are provisional thresholds, not proven safe.
- **45 deterministic tests passed**: 22 existing taker tests, 13 maker/arbitrage
  tests, and 10 new shared-wallet/one-tick tests. This is not an error-free or
  exchange-equivalent fidelity guarantee.

## What this leaves unresolved

A useful maker evaluation still needs a much longer recording with substantial
trade activity **while the odds are near even and the spread can be improved**.
We should not force entries, lower initialization, widen the band or switch
horizons just to manufacture a PnL result. In-play 50/50 prices can still jump
on news, so the band alone is not adverse-selection protection.

The code, raw capture, resolved fee metadata, complete forecasts and zero-trade
ledgers are included in the reproducible bundle. Credentials are excluded.
