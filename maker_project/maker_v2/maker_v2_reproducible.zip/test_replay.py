import unittest
from maker_replay import *

class ReplayTests(unittest.TestCase):
    def setup_ep(self,q=10):
        c=Config();b=Book();b.update([(0,4800,q),(1,5200,q)],0,True)
        ep=Episode(0,0,0,4800,5200,0,(0,),(0,),.5,c)
        ep.step(5_000_000,0,b)
        return ep,b,c
    def test_queue_partial_and_pair_cash(self):
        e,b,c=self.setup_ep()
        e.trade(6_000_000,1,1,4800,10.4,6_000_000)
        self.assertAlmostEqual(e.filled[0],.4)
        e.trade(7_000_000,2,1,4800,.6,7_000_000)
        e.trade(8_000_000,3,0,5200,11,8_000_000)
        self.assertAlmostEqual(e.matched,1)
        r=e.result();self.assertAlmostEqual(r['gross'],.04)
        self.assertAlmostEqual(r['net'],.04-r['fees'])
    def test_touch_and_old_print_do_not_fill(self):
        e,b,c=self.setup_ep()
        b.update([(0,4800,1)],6_000_000);e.step(6_000_000,1,b,True)
        self.assertEqual(e.ahead[0],10)
        e.trade(7_000_000,2,1,4800,100,4_000_000)
        self.assertEqual(e.filled,[0,0])
    def test_through_fill_and_cancel_race(self):
        e,b,c=self.setup_ep();e.cancel(6_000_000,'test')
        e.trade(10_000_000,1,1,4700,.5,10_000_000)
        e.trade(11_000_000,2,1,4700,10,11_000_000)
        self.assertAlmostEqual(e.filled[0],.5)
    def test_post_only_reject(self):
        e,b,c=self.setup_ep();e=Episode(0,0,0,4800,5200,0,(0,),(0,),.5,c)
        b.update([(0,4500,20),(1,4700,20)],5_000_000,True)
        e.step(5_000_000,0,b,True)
        self.assertFalse(e.active);self.assertEqual(e.reason,'post_only_rejected')
    def test_exit_latency_and_real_loss(self):
        e,b,c=self.setup_ep(1);e.trade(6_000_000,1,1,4800,2,6_000_000)
        e.step(10_000_000,50,b,True)
        b.update([(0,4000,10),(1,4200,10)],16_000_000,True)
        e.step(16_000_000,51,b,True);self.assertEqual(e.held[0],1)
        e.step(20_000_000,52,b,True)
        self.assertEqual(e.held[0],0);self.assertLess(e.result()['net'],-.08)
    def test_missing_depth_not_fake_close(self):
        e,b,c=self.setup_ep(1);e.trade(6_000_000,1,1,4800,2,6_000_000)
        e.step(10_000_000,50,b,True)
        b.update([(0,4000,.1),(1,4200,.1)],20_000_000,True)
        e.step(20_000_000,51,b,True)
        self.assertIsNone(e.result()['net']);self.assertIsNone(e.result()['mark_net'])
    def test_labels_mature_at_full_horizon(self):
        e,b,c=self.setup_ep(0.1)
        e.trade(6_000_000,1,1,4800,2,6_000_000)
        e.trade(7_000_000,2,0,5200,2,7_000_000)
        e.step(7_000_000,2,b)
        self.assertIsNone(e.mature_t)
        e.step(50_000_000,50,b);self.assertEqual(e.mature_t,50_000_000)
    def test_no_future_learning(self):
        e,b,c=self.setup_ep(.1)
        e.trade(6_000_000,1,1,4800,2,6_000_000);e.trade(7_000_000,2,0,5200,2,7_000_000)
        e.step(50_000_000,50,b);r=e.result()
        anchors=[dict(id=0,t=40_000_000,key=(0,),coarse=(0,)),dict(id=1,t=51_000_000,key=(0,),coarse=(0,))]
        _,pred,_=evaluate(anchors,[r],c)
        self.assertEqual(pred[0]['n'],0);self.assertEqual(pred[1]['n'],1)
    def test_empty_history_normalized(self):
        p=Rolling().predict(dict(key=(0,),coarse=(0,)),0)
        self.assertAlmostEqual(sum(p['p']),1);self.assertAlmostEqual(sum(p['mid']),1)
    def test_gap_censors_and_keeps_inventory(self):
        e,b,c=self.setup_ep(.1);e.trade(6_000_000,1,1,4800,2,6_000_000)
        e.censored=True;b.valid=False;e.step(8_000_000,2,b)
        self.assertIsNone(e.result()['net']);self.assertIsNone(e.result()['mark_net'])

if __name__=='__main__':unittest.main(verbosity=2)
